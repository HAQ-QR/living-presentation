import { useEffect, useRef } from 'react';

interface Star {
  x: number;
  y: number;
  z: number;
  size: number;
  opacity: number;
  speed: number;
}

interface SpaceObject {
  x: number;
  y: number;
  type: 'asteroid' | 'planet' | 'comet';
  size: number;
  speed: number;
  rotation: number;
  rotationSpeed: number;
  color: string;
}

interface Nebula {
  x: number;
  y: number;
  size: number;
  color: string;
  opacity: number;
  drift: number;
}

export function SpaceBackground() {
  const canvasRef = useRef<HTMLCanvasElement>(null);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    // Set canvas size
    const resize = () => {
      canvas.width = window.innerWidth;
      canvas.height = window.innerHeight;
    };
    resize();
    window.addEventListener('resize', resize);

    // Create stars
    const stars: Star[] = [];
    for (let i = 0; i < 600; i++) {
      stars.push({
        x: Math.random() * canvas.width,
        y: Math.random() * canvas.height,
        z: Math.random() * 2000,
        size: Math.random() * 2.5 + 0.3,
        opacity: Math.random() * 0.9 + 0.1,
        speed: Math.random() * 0.5 + 0.1,
      });
    }

    // Create space objects
    const spaceObjects: SpaceObject[] = [];
    const objectTypes: Array<'asteroid' | 'planet' | 'comet'> = ['asteroid', 'planet', 'comet'];
    const objectColors = ['#6C4CFF', '#00F7FF', '#FF2F92', '#8B5CF6', '#14B8A6'];

    for (let i = 0; i < 25; i++) {
      spaceObjects.push({
        x: Math.random() * canvas.width,
        y: Math.random() * canvas.height,
        type: objectTypes[Math.floor(Math.random() * objectTypes.length)],
        size: Math.random() * 40 + 8,
        speed: Math.random() * 0.3 + 0.04,
        rotation: Math.random() * Math.PI * 2,
        rotationSpeed: (Math.random() - 0.5) * 0.03,
        color: objectColors[Math.floor(Math.random() * objectColors.length)],
      });
    }

    // Create nebulae
    const nebulae: Nebula[] = [];
    const nebulaColors = ['#6C4CFF', '#00F7FF', '#FF2F92', '#8B5CF6', '#14B8A6'];

    for (let i = 0; i < 8; i++) {
      nebulae.push({
        x: Math.random() * canvas.width,
        y: Math.random() * canvas.height,
        size: Math.random() * 120 + 60,
        color: nebulaColors[Math.floor(Math.random() * nebulaColors.length)],
        opacity: Math.random() * 0.3 + 0.1,
        drift: Math.random() * 0.15 + 0.03,
      });
    }

    // Animation loop
    let animationId: number;
    const animate = () => {
      ctx.fillStyle = 'rgba(12, 15, 30, 0.1)';
      ctx.fillRect(0, 0, canvas.width, canvas.height);

      // Draw and update stars
      stars.forEach((star) => {
        // Parallax effect
        const perspective = 1000 / (1000 - star.z);
        const x = (star.x - canvas.width / 2) * perspective + canvas.width / 2;
        const y = (star.y - canvas.height / 2) * perspective + canvas.height / 2;
        const size = star.size * perspective;

        // Twinkling effect
        const twinkle = Math.sin(Date.now() * 0.001 + star.x) * 0.3 + 0.7;

        ctx.beginPath();
        ctx.arc(x, y, size, 0, Math.PI * 2);
        ctx.fillStyle = `rgba(255, 255, 255, ${star.opacity * twinkle})`;
        ctx.shadowBlur = size * 3;
        ctx.shadowColor = 'rgba(255, 255, 255, 0.8)';
        ctx.fill();
        ctx.shadowBlur = 0;

        // Move stars
        star.z -= star.speed;
        if (star.z <= 0) {
          star.z = 2000;
          star.x = Math.random() * canvas.width;
          star.y = Math.random() * canvas.height;
        }
      });

      // Draw and update space objects
      spaceObjects.forEach((obj) => {
        ctx.save();
        ctx.translate(obj.x, obj.y);
        ctx.rotate(obj.rotation);

        if (obj.type === 'asteroid') {
          // Draw irregular asteroid
          ctx.beginPath();
          for (let i = 0; i < 8; i++) {
            const angle = (i / 8) * Math.PI * 2;
            const radius = obj.size * (0.7 + Math.random() * 0.3);
            const x = Math.cos(angle) * radius;
            const y = Math.sin(angle) * radius;
            if (i === 0) ctx.moveTo(x, y);
            else ctx.lineTo(x, y);
          }
          ctx.closePath();
          ctx.fillStyle = obj.color + '40';
          ctx.fill();
          ctx.strokeStyle = obj.color + '80';
          ctx.lineWidth = 1;
          ctx.stroke();

          // Glow effect
          ctx.shadowBlur = 15;
          ctx.shadowColor = obj.color;
          ctx.fill();
          ctx.shadowBlur = 0;
        } else if (obj.type === 'planet') {
          // Draw planet with ring
          const gradient = ctx.createRadialGradient(0, 0, 0, 0, 0, obj.size);
          gradient.addColorStop(0, obj.color + 'AA');
          gradient.addColorStop(0.6, obj.color + '60');
          gradient.addColorStop(1, obj.color + '00');

          ctx.beginPath();
          ctx.arc(0, 0, obj.size, 0, Math.PI * 2);
          ctx.fillStyle = gradient;
          ctx.shadowBlur = 20;
          ctx.shadowColor = obj.color;
          ctx.fill();
          ctx.shadowBlur = 0;

          // Ring
          ctx.beginPath();
          ctx.ellipse(0, 0, obj.size * 1.5, obj.size * 0.3, 0, 0, Math.PI * 2);
          ctx.strokeStyle = obj.color + '50';
          ctx.lineWidth = 2;
          ctx.stroke();
        } else if (obj.type === 'comet') {
          // Draw comet with tail
          const gradient = ctx.createLinearGradient(-obj.size * 3, 0, obj.size, 0);
          gradient.addColorStop(0, obj.color + '00');
          gradient.addColorStop(0.5, obj.color + '60');
          gradient.addColorStop(1, obj.color + 'FF');

          ctx.beginPath();
          ctx.moveTo(-obj.size * 3, 0);
          ctx.lineTo(obj.size, obj.size * 0.3);
          ctx.lineTo(obj.size, -obj.size * 0.3);
          ctx.closePath();
          ctx.fillStyle = gradient;
          ctx.fill();

          // Head
          ctx.beginPath();
          ctx.arc(obj.size, 0, obj.size * 0.4, 0, Math.PI * 2);
          ctx.fillStyle = obj.color;
          ctx.shadowBlur = 15;
          ctx.shadowColor = obj.color;
          ctx.fill();
          ctx.shadowBlur = 0;
        }

        ctx.restore();

        // Move objects
        obj.x -= obj.speed;
        obj.rotation += obj.rotationSpeed;

        // Wrap around
        if (obj.x < -obj.size * 3) {
          obj.x = canvas.width + obj.size * 3;
          obj.y = Math.random() * canvas.height;
        }
      });

      // Draw and update nebulae
      nebulae.forEach((nebula) => {
        ctx.save();
        ctx.translate(nebula.x, nebula.y);

        const gradient = ctx.createRadialGradient(0, 0, 0, 0, 0, nebula.size);
        gradient.addColorStop(0, nebula.color + '30');
        gradient.addColorStop(0.5, nebula.color + '15');
        gradient.addColorStop(1, nebula.color + '00');

        ctx.beginPath();
        ctx.arc(0, 0, nebula.size, 0, Math.PI * 2);
        ctx.fillStyle = gradient;
        ctx.shadowBlur = 40;
        ctx.shadowColor = nebula.color;
        ctx.globalAlpha = nebula.opacity;
        ctx.fill();
        ctx.shadowBlur = 0;
        ctx.globalAlpha = 1;

        ctx.restore();

        // Move nebulae
        nebula.x -= nebula.drift;
        if (nebula.x < -nebula.size * 2) {
          nebula.x = canvas.width + nebula.size * 2;
          nebula.y = Math.random() * canvas.height;
        }
      });

      // Shooting stars occasionally
      if (Math.random() < 0.008) {
        const startX = Math.random() * canvas.width;
        const startY = Math.random() * canvas.height * 0.5;
        const angle = Math.PI / 4 + Math.random() * Math.PI / 6;
        const length = 120 + Math.random() * 150;

        const gradient = ctx.createLinearGradient(
          startX,
          startY,
          startX + Math.cos(angle) * length,
          startY + Math.sin(angle) * length
        );
        gradient.addColorStop(0, 'rgba(255, 255, 255, 0)');
        gradient.addColorStop(0.3, 'rgba(255, 255, 255, 0.8)');
        gradient.addColorStop(1, 'rgba(255, 255, 255, 0)');

        ctx.beginPath();
        ctx.moveTo(startX, startY);
        ctx.lineTo(startX + Math.cos(angle) * length, startY + Math.sin(angle) * length);
        ctx.strokeStyle = gradient;
        ctx.lineWidth = 2;
        ctx.shadowBlur = 10;
        ctx.shadowColor = 'rgba(255, 255, 255, 0.8)';
        ctx.stroke();
        ctx.shadowBlur = 0;
      }

      animationId = requestAnimationFrame(animate);
    };

    animate();

    return () => {
      window.removeEventListener('resize', resize);
      cancelAnimationFrame(animationId);
    };
  }, []);

  return (
    <canvas
      ref={canvasRef}
      style={{
        position: 'fixed',
        top: 0,
        left: 0,
        width: '100%',
        height: '100%',
        zIndex: 1,
        pointerEvents: 'none',
        opacity: 0.35,
        mixBlendMode: 'screen',
      }}
    />
  );
}