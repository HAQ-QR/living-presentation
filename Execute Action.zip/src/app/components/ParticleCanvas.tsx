import { useEffect, useRef } from 'react';

/* ── Types ──────────────────────────────────────────────────── */
interface Particle {
  x: number; y: number;
  vx: number; vy: number;
  radius: number;
  baseRadius: number;
  opacity: number;
  baseOpacity: number;
  color: string;
  colorIdx: number;
  twinkleSpeed: number;
  twinklePhase: number;
  pulsePhase: number;
  pulseSpeed: number;
  isBurst?: boolean;
  life?: number;
  burstDecay?: number;
  type: 'normal' | 'large' | 'tiny';
}

interface ShootingStar {
  x: number; y: number;
  vx: number; vy: number;
  length: number;
  opacity: number;
  life: number;
  color: string;
  width: number;
}

interface NebulaCloud {
  x: number; y: number;
  vx: number; vy: number;
  radius: number;
  opacity: number;
  colorR: number; colorG: number; colorB: number;
  phase: number; phaseSpeed: number;
}

/* ── Constants ──────────────────────────────────────────────── */
const PALETTE = [
  { r: 108, g: 76,  b: 255 },  // violet
  { r: 0,   g: 247, b: 255 },  // cyan
  { r: 255, g: 47,  b: 146 },  // pink
  { r: 160, g: 100, b: 255 },  // lavender
  { r: 0,   g: 200, b: 255 },  // sky blue
  { r: 234, g: 244, b: 255 },  // white
  { r: 80,  g: 255, b: 200 },  // mint
];

function rColor() { return PALETTE[Math.floor(Math.random() * PALETTE.length)]; }
function rRange(min: number, max: number) { return min + Math.random() * (max - min); }

function makeParticle(W: number, H: number): Particle {
  const c = rColor();
  const type = Math.random() < 0.12 ? 'large' : Math.random() < 0.25 ? 'tiny' : 'normal';
  const baseRadius = type === 'large' ? rRange(2.5, 5) : type === 'tiny' ? rRange(0.3, 1) : rRange(0.8, 2.2);
  const baseOpacity = type === 'large' ? rRange(0.4, 0.8) : rRange(0.15, 0.7);
  return {
    x: Math.random() * W,
    y: Math.random() * H,
    vx: (Math.random() - 0.5) * (type === 'large' ? 0.15 : 0.5),
    vy: -(Math.random() * (type === 'large' ? 0.2 : 0.6) + 0.05),
    radius: baseRadius,
    baseRadius,
    opacity: baseOpacity,
    baseOpacity,
    colorIdx: PALETTE.indexOf(c),
    color: `rgba(${c.r},${c.g},${c.b},`,
    twinkleSpeed: rRange(0.01, 0.04),
    twinklePhase: Math.random() * Math.PI * 2,
    pulsePhase: Math.random() * Math.PI * 2,
    pulseSpeed: rRange(0.005, 0.02),
    type,
  };
}

function makeShootingStar(W: number, H: number): ShootingStar {
  const angle = rRange(-0.4, -0.1) * Math.PI;
  const speed = rRange(12, 22);
  const c = rColor();
  return {
    x: rRange(0, W),
    y: rRange(0, H * 0.6),
    vx: Math.cos(angle) * speed,
    vy: Math.sin(angle) * speed,
    length: rRange(120, 280),
    opacity: rRange(0.7, 1),
    life: 1,
    color: `rgba(${c.r},${c.g},${c.b},`,
    width: rRange(1, 2.5),
  };
}

function makeNebula(W: number, H: number): NebulaCloud {
  const c = rColor();
  return {
    x: rRange(0, W),
    y: rRange(0, H),
    vx: (Math.random() - 0.5) * 0.08,
    vy: (Math.random() - 0.5) * 0.06,
    radius: rRange(80, 200),
    opacity: rRange(0.03, 0.1),
    colorR: c.r, colorG: c.g, colorB: c.b,
    phase: Math.random() * Math.PI * 2,
    phaseSpeed: rRange(0.003, 0.01),
  };
}

/* ── Component ──────────────────────────────────────────────── */
export function ParticleCanvas() {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const animRef   = useRef<number>(0);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    let W = window.innerWidth;
    let H = window.innerHeight;
    canvas.width  = W;
    canvas.height = H;

    /* initial pools */
    const COUNT = 220;
    const NEBULA_COUNT = 10;
    const particles: Particle[]      = Array.from({ length: COUNT }, () => makeParticle(W, H));
    const shootingStars: ShootingStar[] = [];
    const nebulae: NebulaCloud[]      = Array.from({ length: NEBULA_COUNT }, () => makeNebula(W, H));

    /* shooting star timer */
    let nextShoot = rRange(1500, 4000);
    let lastTime = performance.now();

    /* Resize */
    const handleResize = () => {
      W = window.innerWidth; H = window.innerHeight;
      canvas.width = W; canvas.height = H;
    };
    window.addEventListener('resize', handleResize);

    /* Burst event */
    const handleBurst = () => {
      /* radial velocity burst on existing particles */
      particles.forEach((p) => {
        if (p.isBurst) return;
        const dx = p.x - W / 2, dy = p.y - H / 2;
        const dist = Math.sqrt(dx * dx + dy * dy) || 1;
        const spd = 5 + Math.random() * 8;
        p.vx = (dx / dist) * spd;
        p.vy = (dy / dist) * spd;
        p.burstDecay = 0.93;
      });
      /* spawn burst particles */
      for (let i = 0; i < 40; i++) {
        const angle = (i / 40) * Math.PI * 2;
        const spd = 6 + Math.random() * 10;
        const c = rColor();
        particles.push({
          x: W / 2 + (Math.random() - 0.5) * 30,
          y: H / 2 + (Math.random() - 0.5) * 30,
          vx: Math.cos(angle) * spd,
          vy: Math.sin(angle) * spd,
          radius: rRange(1.5, 4),
          baseRadius: 2,
          opacity: 1,
          baseOpacity: 1,
          color: `rgba(${c.r},${c.g},${c.b},`,
          colorIdx: 0,
          twinkleSpeed: 0.05,
          twinklePhase: 0,
          pulsePhase: 0,
          pulseSpeed: 0.03,
          isBurst: true,
          life: 1,
          type: 'normal',
        });
      }
      /* spawn 2 shooting stars on burst */
      shootingStars.push(makeShootingStar(W, H));
      shootingStars.push(makeShootingStar(W, H));
    };
    window.addEventListener('slideBurst', handleBurst);

    /* ── Draw loop ─────────────────────────────────────────── */
    const draw = (now: number) => {
      const dt = now - lastTime;
      lastTime = now;

      ctx.clearRect(0, 0, W, H);

      /* ---- Nebulae ---- */
      nebulae.forEach((n) => {
        n.phase += n.phaseSpeed;
        const pulse = 0.7 + 0.3 * Math.sin(n.phase);
        const grd = ctx.createRadialGradient(n.x, n.y, 0, n.x, n.y, n.radius * pulse);
        grd.addColorStop(0, `rgba(${n.colorR},${n.colorG},${n.colorB},${n.opacity})`);
        grd.addColorStop(0.5, `rgba(${n.colorR},${n.colorG},${n.colorB},${n.opacity * 0.4})`);
        grd.addColorStop(1, `rgba(${n.colorR},${n.colorG},${n.colorB},0)`);
        ctx.beginPath();
        ctx.arc(n.x, n.y, n.radius * pulse, 0, Math.PI * 2);
        ctx.fillStyle = grd;
        ctx.fill();
        n.x += n.vx; n.y += n.vy;
        if (n.x < -n.radius) n.x = W + n.radius;
        if (n.x > W + n.radius) n.x = -n.radius;
        if (n.y < -n.radius) n.y = H + n.radius;
        if (n.y > H + n.radius) n.y = -n.radius;
      });

      /* ---- Constellation lines ---- */
      const normals = particles.filter((p) => !p.isBurst && p.type !== 'tiny');
      for (let i = 0; i < normals.length; i++) {
        const p = normals[i];
        for (let j = i + 1; j < normals.length; j++) {
          const q = normals[j];
          const dx = p.x - q.x, dy = p.y - q.y;
          const dist = Math.sqrt(dx * dx + dy * dy);
          if (dist < 140) {
            const alpha = (1 - dist / 140) * 0.18;
            const ci = PALETTE[p.colorIdx] || PALETTE[0];
            ctx.beginPath();
            ctx.moveTo(p.x, p.y);
            ctx.lineTo(q.x, q.y);
            ctx.strokeStyle = `rgba(${ci.r},${ci.g},${ci.b},${alpha.toFixed(3)})`;
            ctx.lineWidth = 0.5;
            ctx.stroke();
          }
        }
      }

      /* ---- Particles ---- */
      const toRemove: number[] = [];
      particles.forEach((p, idx) => {
        /* burst lifecycle */
        if (p.isBurst) {
          p.life! -= 0.018;
          if (p.life! <= 0) { toRemove.push(idx); return; }
          p.opacity = p.life!;
        }

        /* burst velocity decay */
        if (p.burstDecay) {
          p.vx *= p.burstDecay; p.vy *= p.burstDecay;
          if (Math.abs(p.vx) < 0.3 && Math.abs(p.vy) < 0.3) {
            p.vx = (Math.random() - 0.5) * 0.5;
            p.vy = -Math.random() * 0.6 - 0.05;
            p.burstDecay = undefined;
          }
        }

        /* twinkle & pulse */
        p.twinklePhase += p.twinkleSpeed;
        p.pulsePhase   += p.pulseSpeed;
        const twinkle = (Math.sin(p.twinklePhase) + 1) / 2;
        const pulse   = 0.85 + 0.3 * Math.sin(p.pulsePhase);
        const opacity = p.isBurst
          ? p.opacity
          : p.baseOpacity * (0.3 + twinkle * 0.7);
        const r = p.baseRadius * pulse;

        /* core */
        ctx.beginPath();
        ctx.arc(p.x, p.y, r, 0, Math.PI * 2);
        ctx.fillStyle = `${p.color}${opacity.toFixed(3)})`;
        ctx.fill();

        /* glow halo — extra large for 'large' type */
        const haloR = r * (p.type === 'large' ? 7 : 4.5);
        const grd = ctx.createRadialGradient(p.x, p.y, 0, p.x, p.y, haloR);
        grd.addColorStop(0, `${p.color}${(opacity * 0.6).toFixed(3)})`);
        grd.addColorStop(0.4, `${p.color}${(opacity * 0.2).toFixed(3)})`);
        grd.addColorStop(1, `${p.color}0)`);
        ctx.beginPath();
        ctx.arc(p.x, p.y, haloR, 0, Math.PI * 2);
        ctx.fillStyle = grd;
        ctx.fill();

        /* cross-flare for large particles */
        if (p.type === 'large' && opacity > 0.35) {
          ctx.save();
          ctx.globalAlpha = opacity * 0.4;
          ctx.strokeStyle = `${p.color}1)`;
          ctx.lineWidth = 0.6;
          const fl = r * 5;
          ctx.beginPath();
          ctx.moveTo(p.x - fl, p.y);
          ctx.lineTo(p.x + fl, p.y);
          ctx.moveTo(p.x, p.y - fl);
          ctx.lineTo(p.x, p.y + fl);
          ctx.stroke();
          ctx.restore();
        }

        /* move */
        p.x += p.vx; p.y += p.vy;
        if (!p.isBurst) {
          if (p.y < -10) { p.y = H + 10; p.x = Math.random() * W; }
          if (p.x < -10) p.x = W + 10;
          if (p.x > W + 10) p.x = -10;
          if (p.y > H + 10) p.y = -10;
        }
      });

      /* remove dead bursts */
      for (let i = toRemove.length - 1; i >= 0; i--) particles.splice(toRemove[i], 1);

      /* replenish */
      const baseCount = particles.filter((p) => !p.isBurst).length;
      while (baseCount < COUNT) particles.push(makeParticle(W, H));

      /* ---- Shooting stars ---- */
      nextShoot -= dt;
      if (nextShoot <= 0) {
        shootingStars.push(makeShootingStar(W, H));
        if (Math.random() < 0.3) shootingStars.push(makeShootingStar(W, H));
        nextShoot = rRange(2000, 6000);
      }

      const deadStars: number[] = [];
      shootingStars.forEach((s, idx) => {
        s.life -= 0.018;
        if (s.life <= 0) { deadStars.push(idx); return; }

        const tailX = s.x - s.vx * (s.length / (Math.sqrt(s.vx * s.vx + s.vy * s.vy)));
        const tailY = s.y - s.vy * (s.length / (Math.sqrt(s.vx * s.vx + s.vy * s.vy)));

        const grd = ctx.createLinearGradient(tailX, tailY, s.x, s.y);
        grd.addColorStop(0, `${s.color}0)`);
        grd.addColorStop(0.6, `${s.color}${(s.life * s.opacity * 0.5).toFixed(3)})`);
        grd.addColorStop(1, `${s.color}${(s.life * s.opacity).toFixed(3)})`);

        ctx.save();
        ctx.lineWidth = s.width;
        ctx.strokeStyle = grd;
        ctx.shadowColor = `${s.color}0.8)`;
        ctx.shadowBlur = 10;
        ctx.beginPath();
        ctx.moveTo(tailX, tailY);
        ctx.lineTo(s.x, s.y);
        ctx.stroke();

        /* tiny spark at head */
        ctx.beginPath();
        ctx.arc(s.x, s.y, s.width * 2.5, 0, Math.PI * 2);
        ctx.fillStyle = `${s.color}${(s.life * s.opacity).toFixed(3)})`;
        ctx.fill();
        ctx.restore();

        s.x += s.vx; s.y += s.vy;
      });
      for (let i = deadStars.length - 1; i >= 0; i--) shootingStars.splice(deadStars[i], 1);

      animRef.current = requestAnimationFrame(draw);
    };

    animRef.current = requestAnimationFrame(draw);

    return () => {
      cancelAnimationFrame(animRef.current);
      window.removeEventListener('resize', handleResize);
      window.removeEventListener('slideBurst', handleBurst);
    };
  }, []);

  return (
    <canvas
      ref={canvasRef}
      style={{
        position: 'fixed',
        top: 0, left: 0,
        width: '100%', height: '100%',
        pointerEvents: 'none',
        zIndex: 2,
      }}
    />
  );
}
