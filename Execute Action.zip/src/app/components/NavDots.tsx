import { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';

const SECTIONS = [
  '01 · Hero Awakening',
  '02 · Latar Belakang',
  '03 · Product Reveal',
  '04 · Value Power',
  '05 · Analisis Keuangan',
  '06 · Strategi 4P',
  '07 · Analisis Pasar',
  '08 · Rencana Pengembangan',
  '09 · Keunggulan Kompetitif',
  '10 · Visi',
  '11 · Impact',
  '12 · Video Review',
  '13 · Closing',
];

interface NavDotsProps {
  activeSection: number;
  onDotClick: (index: number) => void;
}

export function NavDots({ activeSection, onDotClick }: NavDotsProps) {
  const [hovered, setHovered] = useState<number | null>(null);
  const total = SECTIONS.length;

  return (
    <div
      style={{
        position: 'fixed',
        right: 24,
        top: '50%',
        transform: 'translateY(-50%)',
        zIndex: 100,
        display: 'flex',
        flexDirection: 'column',
        gap: 10,
        alignItems: 'flex-end',
      }}
    >
      {/* Vertical progress track */}
      <div
        style={{
          position: 'absolute',
          right: 4,
          top: 0,
          bottom: 0,
          width: 1,
          background: 'rgba(108,76,255,0.12)',
          borderRadius: 1,
        }}
      >
        <motion.div
          style={{
            width: '100%',
            background: 'linear-gradient(to bottom, #6C4CFF, #00F7FF)',
            borderRadius: 1,
            originY: 0,
            boxShadow: '0 0 6px rgba(108,76,255,0.8)',
          }}
          animate={{ scaleY: (activeSection + 1) / total }}
          transition={{ duration: 0.6, ease: [0.25, 0.46, 0.45, 0.94] }}
        />
      </div>

      {SECTIONS.map((name, i) => {
        const isActive = i === activeSection;
        const isHovered = i === hovered;
        const isPast = i < activeSection;

        return (
          <div
            key={i}
            style={{ display: 'flex', alignItems: 'center', gap: 8, cursor: 'pointer', position: 'relative' }}
            onClick={() => onDotClick(i)}
            onMouseEnter={() => setHovered(i)}
            onMouseLeave={() => setHovered(null)}
          >
            {/* Label */}
            <AnimatePresence>
              {isHovered && (
                <motion.span
                  initial={{ opacity: 0, x: 8 }}
                  animate={{ opacity: 1, x: 0 }}
                  exit={{ opacity: 0, x: 8 }}
                  transition={{ duration: 0.18 }}
                  style={{
                    fontFamily: "'Space Grotesk', sans-serif",
                    fontSize: 11,
                    color: 'rgba(234,244,255,0.85)',
                    background: 'rgba(12,15,30,0.92)',
                    backdropFilter: 'blur(12px)',
                    border: '1px solid rgba(108,76,255,0.35)',
                    padding: '3px 10px',
                    borderRadius: 6,
                    whiteSpace: 'nowrap',
                    letterSpacing: '0.05em',
                    boxShadow: '0 0 12px rgba(108,76,255,0.2)',
                  }}
                >
                  {name}
                </motion.span>
              )}
            </AnimatePresence>

            {/* Dot container */}
            <div style={{ position: 'relative', width: 16, height: 16, display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
              {/* Active outer pulse ring */}
              {isActive && (
                <motion.div
                  animate={{ scale: [1, 1.8, 1], opacity: [0.5, 0, 0.5] }}
                  transition={{ duration: 2, repeat: Infinity, ease: 'easeInOut' }}
                  style={{
                    position: 'absolute',
                    width: 14,
                    height: 14,
                    borderRadius: '50%',
                    border: '1px solid #6C4CFF',
                    boxShadow: '0 0 8px rgba(108,76,255,0.6)',
                  }}
                />
              )}

              {/* Dot */}
              <motion.div
                animate={{
                  width: isActive ? 10 : isHovered ? 8 : 5,
                  height: isActive ? 10 : isHovered ? 8 : 5,
                  background: isActive
                    ? '#6C4CFF'
                    : isHovered
                    ? '#00F7FF'
                    : isPast
                    ? 'rgba(108,76,255,0.5)'
                    : 'rgba(234,244,255,0.18)',
                  boxShadow: isActive
                    ? '0 0 14px rgba(108,76,255,1), 0 0 28px rgba(108,76,255,0.5)'
                    : isHovered
                    ? '0 0 10px rgba(0,247,255,0.9)'
                    : isPast
                    ? '0 0 6px rgba(108,76,255,0.4)'
                    : 'none',
                }}
                transition={{ duration: 0.25 }}
                style={{
                  borderRadius: '50%',
                  flexShrink: 0,
                }}
              />
            </div>
          </div>
        );
      })}
    </div>
  );
}