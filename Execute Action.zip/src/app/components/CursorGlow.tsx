import { useEffect, useRef, useState } from 'react';

const TRAIL_LEN = 20;

const CURSOR_COLORS = [
  { outer: 'rgba(108,76,255,', inner: 'rgba(0,247,255,', shadow: '108,76,255' },
  { outer: 'rgba(0,247,255,', inner: 'rgba(108,76,255,', shadow: '0,247,255' },
  { outer: 'rgba(255,47,146,', inner: 'rgba(0,247,255,', shadow: '255,47,146' },
];

export function CursorGlow() {
  const [pos, setPos] = useState({ x: -300, y: -300 });
  const [trail, setTrail] = useState<{ x: number; y: number; id: number }[]>([]);
  const [colorIdx, setColorIdx] = useState(0);
  const idRef = useRef(0);
  const colorTimerRef = useRef<ReturnType<typeof setInterval> | null>(null);
  const velRef = useRef({ x: 0, y: 0 });
  const prevPosRef = useRef({ x: -300, y: -300 });

  useEffect(() => {
    const handleMove = (e: MouseEvent) => {
      const nx = e.clientX, ny = e.clientY;
      velRef.current = {
        x: nx - prevPosRef.current.x,
        y: ny - prevPosRef.current.y,
      };
      prevPosRef.current = { x: nx, y: ny };
      setPos({ x: nx, y: ny });
      const id = idRef.current++;
      setTrail((prev) => [...prev.slice(-(TRAIL_LEN - 1)), { x: nx, y: ny, id }]);
    };
    window.addEventListener('mousemove', handleMove);

    colorTimerRef.current = setInterval(() => {
      setColorIdx((c) => (c + 1) % CURSOR_COLORS.length);
    }, 3000);

    return () => {
      window.removeEventListener('mousemove', handleMove);
      if (colorTimerRef.current) clearInterval(colorTimerRef.current);
    };
  }, []);

  const col = CURSOR_COLORS[colorIdx];
  const speed = Math.sqrt(velRef.current.x ** 2 + velRef.current.y ** 2);
  const cursorScale = Math.min(1 + speed * 0.04, 2.2);

  return (
    <div style={{ position: 'fixed', top: 0, left: 0, pointerEvents: 'none', zIndex: 9999 }}>
      {/* Trail dots */}
      {trail.map((t, i) => {
        const ratio = i / trail.length;
        const size = 4 + ratio * 10;
        return (
          <div
            key={t.id}
            style={{
              position: 'fixed',
              left: t.x - size / 2,
              top: t.y - size / 2,
              width: size,
              height: size,
              borderRadius: '50%',
              background: `${col.inner}${(ratio * 0.55).toFixed(3)})`,
              boxShadow: `0 0 ${8 + ratio * 16}px ${col.inner}0.7)`,
              transform: `scale(${ratio})`,
              transition: 'transform 0.08s ease',
              pointerEvents: 'none',
            }}
          />
        );
      })}

      {/* Outer ring */}
      <div
        style={{
          position: 'fixed',
          left: pos.x - 20,
          top: pos.y - 20,
          width: 40,
          height: 40,
          borderRadius: '50%',
          border: `1.5px solid ${col.outer}0.9)`,
          boxShadow: `0 0 18px ${col.outer}0.6), 0 0 36px ${col.outer}0.25), inset 0 0 12px ${col.outer}0.1)`,
          transform: `scale(${cursorScale})`,
          transition: 'left 0.06s ease, top 0.06s ease, transform 0.2s ease, border-color 0.8s ease, box-shadow 0.8s ease',
          pointerEvents: 'none',
        }}
      />

      {/* Middle pulse ring */}
      <div
        style={{
          position: 'fixed',
          left: pos.x - 14,
          top: pos.y - 14,
          width: 28,
          height: 28,
          borderRadius: '50%',
          border: `1px solid ${col.inner}0.4)`,
          transition: 'left 0.04s ease, top 0.04s ease, border-color 0.8s ease',
          pointerEvents: 'none',
        }}
      />

      {/* Core dot */}
      <div
        style={{
          position: 'fixed',
          left: pos.x - 4,
          top: pos.y - 4,
          width: 8,
          height: 8,
          borderRadius: '50%',
          background: `${col.inner}1)`,
          boxShadow: `0 0 12px ${col.inner}1), 0 0 24px ${col.outer}0.8), 0 0 40px ${col.outer}0.4)`,
          transition: 'background 0.8s ease, box-shadow 0.8s ease',
          pointerEvents: 'none',
        }}
      />

      {/* Speed-based glow aura */}
      {speed > 5 && (
        <div
          style={{
            position: 'fixed',
            left: pos.x - 40,
            top: pos.y - 40,
            width: 80,
            height: 80,
            borderRadius: '50%',
            background: `radial-gradient(circle, ${col.outer}${Math.min(speed * 0.008, 0.25).toFixed(3)}) 0%, transparent 70%)`,
            pointerEvents: 'none',
            transition: 'left 0.1s ease, top 0.1s ease',
          }}
        />
      )}
    </div>
  );
}
