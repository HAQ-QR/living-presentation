import { useEffect, useState } from 'react';
import { AnimatePresence, motion } from 'motion/react';

interface Props {
  trigger: number;
  direction: number;
}

const WARP_LINES = [8, 18, 28, 38, 50, 62, 72, 82, 92];

export function SlideTransitionOverlay({ trigger, direction }: Props) {
  const [show, setShow] = useState(false);

  useEffect(() => {
    if (trigger === 0) return;
    setShow(true);
    const timer = setTimeout(() => setShow(false), 700);
    return () => clearTimeout(timer);
  }, [trigger]);

  return (
    <AnimatePresence>
      {show && (
        <>
          {/* Central radial neon flash */}
          <motion.div
            key={`flash-${trigger}`}
            initial={{ opacity: 0 }}
            animate={{ opacity: [0, 0.85, 0.4, 0] }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.55, times: [0, 0.1, 0.4, 1], ease: 'easeOut' }}
            style={{
              position: 'fixed',
              inset: 0,
              zIndex: 8995,
              pointerEvents: 'none',
              background:
                'radial-gradient(ellipse at 50% 50%, rgba(108,76,255,0.6) 0%, rgba(0,247,255,0.25) 35%, rgba(255,47,146,0.1) 60%, transparent 80%)',
            }}
          />

          {/* Vignette tighten */}
          <motion.div
            key={`vignette-${trigger}`}
            initial={{ opacity: 0 }}
            animate={{ opacity: [0, 0.9, 0] }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.5, times: [0, 0.2, 1] }}
            style={{
              position: 'fixed',
              inset: 0,
              zIndex: 8994,
              pointerEvents: 'none',
              background:
                'radial-gradient(ellipse at center, transparent 20%, rgba(0,0,0,0.7) 100%)',
            }}
          />

          {/* Primary scan line */}
          <motion.div
            key={`scan-${trigger}`}
            initial={{ y: direction > 0 ? '110vh' : '-110vh' }}
            animate={{ y: direction > 0 ? '-110vh' : '110vh' }}
            exit={{}}
            transition={{ duration: 0.48, ease: [0.76, 0, 0.24, 1] }}
            style={{
              position: 'fixed',
              left: 0,
              right: 0,
              height: 4,
              zIndex: 9000,
              pointerEvents: 'none',
              background:
                'linear-gradient(90deg, transparent 0%, #6C4CFF 15%, #00F7FF 50%, #FF2F92 85%, transparent 100%)',
              boxShadow:
                '0 0 20px rgba(0,247,255,1), 0 0 40px rgba(108,76,255,0.8), 0 0 80px rgba(108,76,255,0.4)',
            }}
          />

          {/* Secondary thinner scan line */}
          <motion.div
            key={`scan2-${trigger}`}
            initial={{ y: direction > 0 ? '110vh' : '-110vh' }}
            animate={{ y: direction > 0 ? '-110vh' : '110vh' }}
            exit={{}}
            transition={{ duration: 0.48, ease: [0.76, 0, 0.24, 1], delay: 0.04 }}
            style={{
              position: 'fixed',
              left: 0,
              right: 0,
              height: 1,
              zIndex: 8999,
              pointerEvents: 'none',
              background:
                'linear-gradient(90deg, transparent 0%, rgba(0,247,255,0.5) 30%, rgba(255,47,146,0.8) 50%, rgba(0,247,255,0.5) 70%, transparent 100%)',
              boxShadow: '0 0 10px rgba(0,247,255,0.6)',
            }}
          />

          {/* Horizontal warp streaks */}
          {WARP_LINES.map((yPercent, i) => (
            <motion.div
              key={`warp-${trigger}-${i}`}
              initial={{ scaleX: 0, opacity: 0 }}
              animate={{ scaleX: [0, 1, 0], opacity: [0, 0.6, 0] }}
              exit={{}}
              transition={{
                duration: 0.3 + i * 0.01,
                delay: i * 0.018,
                ease: 'easeInOut',
              }}
              style={{
                position: 'fixed',
                top: `${yPercent}%`,
                left: 0,
                right: 0,
                height: i % 3 === 0 ? 1.5 : 0.5,
                background:
                  i % 3 === 0
                    ? 'rgba(108,76,255,0.9)'
                    : i % 3 === 1
                    ? 'rgba(0,247,255,0.7)'
                    : 'rgba(255,47,146,0.6)',
                transformOrigin: 'center',
                zIndex: 8997,
                pointerEvents: 'none',
                boxShadow:
                  i % 3 === 0
                    ? '0 0 6px rgba(108,76,255,0.8)'
                    : i % 3 === 1
                    ? '0 0 6px rgba(0,247,255,0.7)'
                    : '0 0 6px rgba(255,47,146,0.6)',
              }}
            />
          ))}

          {/* Corner neon sparks */}
          {[
            { top: 0, left: 0, color: '#6C4CFF' },
            { top: 0, right: 0, color: '#00F7FF' },
            { bottom: 0, left: 0, color: '#00F7FF' },
            { bottom: 0, right: 0, color: '#FF2F92' },
          ].map((c, i) => (
            <motion.div
              key={`corner-${trigger}-${i}`}
              initial={{ opacity: 0, scale: 0.2 }}
              animate={{ opacity: [0, 1, 0.6, 0], scale: [0.2, 1.4, 1.8, 2.5] }}
              exit={{}}
              transition={{ duration: 0.45, delay: i * 0.04, ease: 'easeOut' }}
              style={{
                position: 'fixed',
                width: 80,
                height: 80,
                zIndex: 8998,
                pointerEvents: 'none',
                background: `radial-gradient(circle, ${c.color}99 0%, transparent 70%)`,
                top: c.top,
                left: (c as any).left,
                right: (c as any).right,
                bottom: (c as any).bottom,
              }}
            />
          ))}

          {/* Center starburst */}
          <motion.div
            key={`starburst-${trigger}`}
            initial={{ opacity: 0, scale: 0.1, rotate: 0 }}
            animate={{ opacity: [0, 0.6, 0], scale: [0.1, 1.5, 2.5], rotate: 45 }}
            exit={{}}
            transition={{ duration: 0.4, ease: 'easeOut' }}
            style={{
              position: 'fixed',
              top: '50%',
              left: '50%',
              transform: 'translate(-50%, -50%)',
              width: 200,
              height: 200,
              zIndex: 8996,
              pointerEvents: 'none',
              background:
                'conic-gradient(from 0deg, transparent 0deg, rgba(108,76,255,0.3) 10deg, transparent 20deg, rgba(0,247,255,0.3) 30deg, transparent 40deg, rgba(255,47,146,0.2) 50deg, transparent 60deg, rgba(108,76,255,0.3) 70deg, transparent 80deg, transparent 90deg)',
              borderRadius: '50%',
              filter: 'blur(2px)',
            }}
          />
        </>
      )}
    </AnimatePresence>
  );
}
