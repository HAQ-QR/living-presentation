import { motion, useInView } from 'motion/react';
import { useRef, useState } from 'react';
import productImage from 'figma:asset/67ba4e60f3abad7394355c518e223d1cd5f9384e.png';

const PRODUCTS = [
  { icon: '📓', name: 'Notebook Premium', sub: 'Minimalis & Berkualitas', color: '#6C4CFF' },
  { icon: '🖊️', name: 'Pulpen Estetik', sub: 'Smooth & Stylish', color: '#00F7FF' },
  { icon: '🗒️', name: 'Sticky Notes Pastel', sub: 'Warna Cerah & Ceria', color: '#FF2F92' },
  { icon: '💌', name: 'Kartu Motivasi', sub: 'Personal & Penuh Makna', color: '#6C4CFF' },
];

export function Section03ProductReveal() {
  const ref = useRef<HTMLDivElement>(null);
  const isInView = useInView(ref, { once: false, amount: 0.2 });
  const [hovered, setHovered] = useState<number | null>(null);

  return (
    <div
      ref={ref}
      style={{
        minHeight: '100vh',
        background: '#0C0F1E',
        position: 'relative',
        overflow: 'hidden',
        display: 'flex',
        flexDirection: 'column',
        alignItems: 'center',
        justifyContent: 'center',
        padding: '60px 80px',
        fontFamily: "'Space Grotesk', sans-serif",
      }}
    >
      {/* BG orbs */}
      <div style={{ position: 'absolute', top: '20%', left: '50%', transform: 'translateX(-50%)', width: 600, height: 600, background: 'radial-gradient(circle, rgba(108,76,255,0.15) 0%, transparent 70%)', borderRadius: '50%', pointerEvents: 'none' }} />
      <div style={{ position: 'absolute', bottom: '10%', right: '10%', width: 300, height: 300, background: 'radial-gradient(circle, rgba(0,247,255,0.08) 0%, transparent 70%)', borderRadius: '50%', pointerEvents: 'none' }} />
      <div style={{ position: 'absolute', top: '10%', left: '5%', width: 250, height: 250, background: 'radial-gradient(circle, rgba(255,47,146,0.07) 0%, transparent 70%)', borderRadius: '50%', pointerEvents: 'none' }} />

      <div style={{ position: 'relative', zIndex: 2, width: '100%', maxWidth: 1100, textAlign: 'center' }}>

        {/* Section label */}
        <motion.div initial={{ opacity: 0 }} animate={isInView ? { opacity: 1 } : {}} transition={{ duration: 0.6 }}
          style={{ marginBottom: 20, display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 10 }}>
          <span style={{ fontSize: 11, color: '#6C4CFF', letterSpacing: '0.2em', textTransform: 'uppercase', fontWeight: 600 }}>Section 03</span>
          <span style={{ width: 40, height: 1, background: 'rgba(108,76,255,0.5)' }} />
          <span style={{ fontSize: 11, color: 'rgba(234,244,255,0.4)', letterSpacing: '0.15em', textTransform: 'uppercase' }}>Product Reveal</span>
        </motion.div>

        <motion.h2
          initial={{ opacity: 0, y: 30 }}
          animate={isInView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.8, delay: 0.2 }}
          style={{
            fontFamily: "'Orbitron', monospace",
            fontSize: 'clamp(28px, 4vw, 52px)',
            fontWeight: 700,
            background: 'linear-gradient(135deg, #6C4CFF, #00F7FF)',
            WebkitBackgroundClip: 'text',
            WebkitTextFillColor: 'transparent',
            backgroundClip: 'text',
            marginBottom: 12,
          }}
        >
          Isi Paket
        </motion.h2>

        {/* Product Image with neon frame */}
        <motion.div
          initial={{ opacity: 0, scale: 0.7, y: 40 }}
          animate={isInView ? { opacity: 1, scale: 1, y: 0 } : {}}
          transition={{ duration: 1, delay: 0.3, type: 'spring', stiffness: 80 }}
          style={{ marginBottom: 48, display: 'flex', justifyContent: 'center', position: 'relative' }}
        >
          {/* Outer shockwave rings */}
          {[0, 1, 2].map(i => (
            <div key={i} style={{
              position: 'absolute',
              top: '50%',
              left: '50%',
              transform: 'translate(-50%, -50%)',
              width: `${340 + i * 80}px`,
              height: `${340 + i * 80}px`,
              border: `1px solid rgba(108,76,255,${0.4 - i * 0.1})`,
              borderRadius: '50%',
              boxShadow: `0 0 ${20 + i * 10}px rgba(108,76,255,${0.2 - i * 0.05})`,
              animation: `shockwaveRing ${2.5 + i * 0.6}s ease-out infinite ${i * 0.7}s`,
              pointerEvents: 'none',
            }} />
          ))}

          {/* Glow backdrop */}
          <div style={{
            position: 'absolute',
            top: '50%',
            left: '50%',
            transform: 'translate(-50%, -50%)',
            width: 320,
            height: 320,
            background: 'radial-gradient(circle, rgba(108,76,255,0.35) 0%, rgba(0,247,255,0.1) 50%, transparent 75%)',
            borderRadius: '50%',
            filter: 'blur(30px)',
            pointerEvents: 'none',
          }} />

          {/* Product image container */}
          <div
            style={{
              position: 'relative',
              animation: 'float 4s ease-in-out infinite',
              borderRadius: 20,
              overflow: 'hidden',
              boxShadow: '0 0 0 1px rgba(108,76,255,0.4), 0 0 40px rgba(108,76,255,0.5), 0 0 80px rgba(0,247,255,0.2), 0 30px 60px rgba(0,0,0,0.6)',
            }}
          >
            {/* Neon border frame */}
            <div style={{
              position: 'absolute',
              inset: 0,
              borderRadius: 20,
              border: '2px solid transparent',
              background: 'linear-gradient(135deg, rgba(108,76,255,0.8), rgba(0,247,255,0.6), rgba(255,47,146,0.4), rgba(108,76,255,0.8)) border-box',
              WebkitMask: 'linear-gradient(#fff 0 0) padding-box, linear-gradient(#fff 0 0)',
              WebkitMaskComposite: 'destination-out',
              maskComposite: 'exclude',
              zIndex: 2,
              pointerEvents: 'none',
            }} />

            {/* Corner accent lights */}
            {['top-left', 'top-right', 'bottom-left', 'bottom-right'].map((corner) => (
              <div key={corner} style={{
                position: 'absolute',
                width: 40,
                height: 40,
                zIndex: 3,
                pointerEvents: 'none',
                ...(corner === 'top-left' ? { top: -1, left: -1, borderTop: '2px solid #6C4CFF', borderLeft: '2px solid #6C4CFF', borderTopLeftRadius: 20 } : {}),
                ...(corner === 'top-right' ? { top: -1, right: -1, borderTop: '2px solid #00F7FF', borderRight: '2px solid #00F7FF', borderTopRightRadius: 20 } : {}),
                ...(corner === 'bottom-left' ? { bottom: -1, left: -1, borderBottom: '2px solid #00F7FF', borderLeft: '2px solid #00F7FF', borderBottomLeftRadius: 20 } : {}),
                ...(corner === 'bottom-right' ? { bottom: -1, right: -1, borderBottom: '2px solid #FF2F92', borderRight: '2px solid #FF2F92', borderBottomRightRadius: 20 } : {}),
              }} />
            ))}

            <img
              src={productImage}
              alt="Thoughtful Beginning — Hampers Alat Tulis Estetik"
              style={{
                width: 300,
                height: 300,
                objectFit: 'cover',
                display: 'block',
                borderRadius: 18,
              }}
            />

            {/* Shine overlay */}
            <div style={{
              position: 'absolute',
              inset: 0,
              background: 'linear-gradient(135deg, rgba(255,255,255,0.08) 0%, transparent 50%, rgba(108,76,255,0.05) 100%)',
              borderRadius: 18,
              pointerEvents: 'none',
            }} />
          </div>

          {/* Floating badge */}
          <motion.div
            initial={{ opacity: 0, x: 20 }}
            animate={isInView ? { opacity: 1, x: 0 } : {}}
            transition={{ duration: 0.6, delay: 0.9 }}
            style={{
              position: 'absolute',
              top: 10,
              right: 'calc(50% - 210px)',
              background: 'rgba(108,76,255,0.2)',
              backdropFilter: 'blur(20px)',
              border: '1px solid rgba(108,76,255,0.5)',
              borderRadius: 12,
              padding: '8px 16px',
              textAlign: 'left',
            }}
          >
            <div style={{ fontSize: 10, color: 'rgba(234,244,255,0.5)', letterSpacing: '0.15em', textTransform: 'uppercase', marginBottom: 2 }}>Premium Pack</div>
            <div style={{ fontSize: 14, color: '#00F7FF', fontWeight: 700 }}>Limited Edition</div>
          </motion.div>

          {/* Floating badge 2 */}
          <motion.div
            initial={{ opacity: 0, x: -20 }}
            animate={isInView ? { opacity: 1, x: 0 } : {}}
            transition={{ duration: 0.6, delay: 1.0 }}
            style={{
              position: 'absolute',
              bottom: 10,
              left: 'calc(50% - 210px)',
              background: 'rgba(255,47,146,0.15)',
              backdropFilter: 'blur(20px)',
              border: '1px solid rgba(255,47,146,0.4)',
              borderRadius: 12,
              padding: '8px 16px',
              textAlign: 'left',
            }}
          >
            <div style={{ fontSize: 10, color: 'rgba(234,244,255,0.5)', letterSpacing: '0.15em', textTransform: 'uppercase', marginBottom: 2 }}>Dikemas dengan</div>
            <div style={{ fontSize: 14, color: '#FF2F92', fontWeight: 700 }}>Box Elegan</div>
          </motion.div>
        </motion.div>

        {/* Description */}
        <motion.p
          initial={{ opacity: 0 }}
          animate={isInView ? { opacity: 1 } : {}}
          transition={{ duration: 0.8, delay: 0.5 }}
          style={{ fontSize: 14, color: 'rgba(234,244,255,0.45)', marginBottom: 44, letterSpacing: '0.05em' }}
        >
          Dikemas dalam box elegan dengan sentuhan modern.
        </motion.p>

        {/* 4 Product Cards */}
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: 20 }}>
          {PRODUCTS.map((p, i) => (
            <motion.div
              key={i}
              initial={{ opacity: 0, y: 50 }}
              animate={isInView ? { opacity: 1, y: 0 } : {}}
              transition={{ duration: 0.6, delay: 0.4 + i * 0.1 }}
              onMouseEnter={() => setHovered(i)}
              onMouseLeave={() => setHovered(null)}
              style={{
                background: 'rgba(255,255,255,0.03)',
                backdropFilter: 'blur(20px)',
                border: `1px solid ${hovered === i ? p.color + '80' : 'rgba(255,255,255,0.07)'}`,
                borderRadius: 20,
                padding: '28px 20px',
                textAlign: 'center',
                cursor: 'pointer',
                transform: hovered === i ? 'scale(1.05) translateY(-4px)' : 'scale(1) translateY(0)',
                boxShadow: hovered === i ? `0 0 30px ${p.color}40, 0 20px 40px rgba(0,0,0,0.3)` : '0 4px 20px rgba(0,0,0,0.2)',
                transition: 'all 0.3s cubic-bezier(0.4, 0, 0.2, 1)',
                position: 'relative',
                overflow: 'hidden',
              }}
            >
              {/* Top accent */}
              <div style={{ position: 'absolute', top: 0, left: 0, right: 0, height: 2, background: `linear-gradient(90deg, transparent, ${p.color}, transparent)`, opacity: hovered === i ? 1 : 0.3, transition: 'opacity 0.3s' }} />

              <div style={{ fontSize: 40, marginBottom: 14, filter: hovered === i ? `drop-shadow(0 0 15px ${p.color})` : 'none', transition: 'filter 0.3s' }}>
                {p.icon}
              </div>
              <div style={{
                fontSize: 14,
                fontWeight: 600,
                color: hovered === i ? p.color : 'rgba(234,244,255,0.9)',
                marginBottom: 6,
                transition: 'color 0.3s',
              }}>
                {p.name}
              </div>
              <div style={{ fontSize: 12, color: 'rgba(234,244,255,0.4)', lineHeight: 1.5 }}>
                {p.sub}
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </div>
  );
}