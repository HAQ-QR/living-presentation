import { motion } from 'motion/react';
import { useRef } from 'react';

interface HeroProps {
  onStart: () => void;
}

export function Section01Hero({ onStart }: HeroProps) {
  const ref = useRef<HTMLDivElement>(null);

  return (
    <div
      ref={ref}
      style={{
        minHeight: '100vh',
        background: '#0C0F1E',
        position: 'relative',
        overflow: 'hidden',
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'center',
        fontFamily: "'Space Grotesk', sans-serif",
      }}
    >
      {/* Deep radial glow center */}
      <div style={{
        position: 'absolute',
        top: '50%',
        left: '50%',
        transform: 'translate(-50%, -50%)',
        width: 700,
        height: 700,
        background: 'radial-gradient(circle, rgba(108,76,255,0.25) 0%, rgba(108,76,255,0.08) 40%, transparent 70%)',
        borderRadius: '50%',
        pointerEvents: 'none',
        animation: 'heroPulse 4s ease-in-out infinite',
      }} />
      <div style={{
        position: 'absolute',
        top: '50%',
        left: '50%',
        transform: 'translate(-50%, -50%)',
        width: 400,
        height: 400,
        background: 'radial-gradient(circle, rgba(0,247,255,0.1) 0%, transparent 70%)',
        borderRadius: '50%',
        pointerEvents: 'none',
        animation: 'heroPulse 4s ease-in-out infinite 1s',
      }} />

      {/* Top corner accent */}
      <div style={{
        position: 'absolute',
        top: -200,
        right: -200,
        width: 500,
        height: 500,
        background: 'radial-gradient(circle, rgba(255,47,146,0.12) 0%, transparent 70%)',
        borderRadius: '50%',
        pointerEvents: 'none',
      }} />
      <div style={{
        position: 'absolute',
        bottom: -200,
        left: -200,
        width: 500,
        height: 500,
        background: 'radial-gradient(circle, rgba(108,76,255,0.1) 0%, transparent 70%)',
        borderRadius: '50%',
        pointerEvents: 'none',
      }} />

      {/* Content */}
      <div style={{ position: 'relative', zIndex: 2, textAlign: 'center', maxWidth: 860, padding: '0 40px' }}>

        {/* Badge */}
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.2, duration: 0.8 }}
          style={{
            display: 'inline-flex',
            alignItems: 'center',
            gap: 8,
            background: 'rgba(108,76,255,0.15)',
            border: '1px solid rgba(108,76,255,0.4)',
            borderRadius: 40,
            padding: '6px 18px',
            marginBottom: 32,
          }}
        >
          <span style={{ width: 7, height: 7, borderRadius: '50%', background: '#6C4CFF', boxShadow: '0 0 8px rgba(108,76,255,1)', display: 'inline-block' }} />
          <span style={{ fontSize: 12, color: 'rgba(234,244,255,0.7)', letterSpacing: '0.15em', textTransform: 'uppercase' }}>
            Presentasi Produk 2025
          </span>
        </motion.div>

        {/* Main Title */}
        <motion.h1
          initial={{ opacity: 0, y: 40 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.4, duration: 1, ease: 'easeOut' }}
          style={{
            fontFamily: "'Orbitron', monospace",
            fontSize: 'clamp(40px, 6vw, 80px)',
            fontWeight: 900,
            letterSpacing: '0.08em',
            lineHeight: 1.1,
            marginBottom: 24,
            background: 'linear-gradient(135deg, #6C4CFF 0%, #00F7FF 50%, #6C4CFF 100%)',
            backgroundSize: '200% auto',
            WebkitBackgroundClip: 'text',
            WebkitTextFillColor: 'transparent',
            backgroundClip: 'text',
            animation: 'sweepText 4s linear infinite',
            textShadow: 'none',
          }}
        >
          THOUGHTFUL<br />BEGINNING
        </motion.h1>

        {/* Subtitle */}
        <motion.p
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.7, duration: 0.8 }}
          style={{
            fontSize: 'clamp(16px, 2vw, 22px)',
            color: 'rgba(234,244,255,0.9)',
            marginBottom: 16,
            letterSpacing: '0.03em',
          }}
        >
          Hampers Alat Tulis Estetik untuk Pelajar Modern
        </motion.p>

        {/* Supporting text */}
        <motion.p
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 1, duration: 0.8 }}
          style={{
            fontSize: 'clamp(13px, 1.4vw, 16px)',
            color: 'rgba(234,244,255,0.5)',
            marginBottom: 52,
            lineHeight: 1.7,
            maxWidth: 520,
            margin: '0 auto 52px',
          }}
        >
          Sebuah hadiah sederhana yang membawa semangat baru<br />dalam setiap langkah pendidikan.
        </motion.p>

        {/* CTA Button */}
        <motion.div
          initial={{ opacity: 0, scale: 0.8 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ delay: 1.2, duration: 0.6, type: 'spring' }}
        >
          <button
            onClick={onStart}
            style={{
              position: 'relative',
              padding: '16px 48px',
              fontSize: 15,
              fontFamily: "'Orbitron', monospace",
              fontWeight: 600,
              letterSpacing: '0.15em',
              color: '#EAF4FF',
              background: 'rgba(108,76,255,0.2)',
              backdropFilter: 'blur(20px)',
              border: '1px solid rgba(108,76,255,0.6)',
              borderRadius: 50,
              cursor: 'pointer',
              boxShadow: '0 0 30px rgba(108,76,255,0.4), 0 0 60px rgba(108,76,255,0.15), inset 0 0 20px rgba(108,76,255,0.1)',
              animation: 'btnPulse 2.5s ease-in-out infinite',
              overflow: 'hidden',
              transition: 'all 0.3s ease',
            }}
            onMouseEnter={e => {
              (e.target as HTMLButtonElement).style.transform = 'scale(1.05)';
              (e.target as HTMLButtonElement).style.boxShadow = '0 0 40px rgba(108,76,255,0.7), 0 0 80px rgba(108,76,255,0.3)';
            }}
            onMouseLeave={e => {
              (e.target as HTMLButtonElement).style.transform = 'scale(1)';
              (e.target as HTMLButtonElement).style.boxShadow = '0 0 30px rgba(108,76,255,0.4), 0 0 60px rgba(108,76,255,0.15), inset 0 0 20px rgba(108,76,255,0.1)';
            }}
          >
            ▶ &nbsp; Mulai Presentasi
          </button>
        </motion.div>

        {/* Scroll hint */}
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 2, duration: 1 }}
          style={{ marginTop: 60, display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 6 }}
        >
          <span style={{ fontSize: 11, color: 'rgba(234,244,255,0.3)', letterSpacing: '0.2em', textTransform: 'uppercase' }}>Scroll</span>
          <div style={{ width: 1, height: 40, background: 'linear-gradient(to bottom, rgba(108,76,255,0.6), transparent)', animation: 'scrollPulse 2s ease-in-out infinite' }} />
        </motion.div>
      </div>
    </div>
  );
}
