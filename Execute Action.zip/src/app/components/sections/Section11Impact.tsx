import { motion, useInView } from 'motion/react';
import { useRef } from 'react';

const IMPACTS = [
  {
    text: 'Meningkatkan',
    highlight: 'motivasi belajar.',
    desc: 'Setiap pelajar yang menerima Thoughtful Beginning merasakan dorongan semangat yang nyata dalam perjalanan akademiknya.',
    color: '#6C4CFF',
    icon: '📚',
  },
  {
    text: 'Memberikan',
    highlight: 'makna dalam setiap hadiah.',
    desc: 'Produk yang bukan sekadar benda — melainkan ekspresi dari perhatian, doa, dan dukungan yang tulus dari sang pemberi.',
    color: '#00F7FF',
    icon: '💝',
  },
  {
    text: 'Membangun',
    highlight: 'usaha kreatif yang berkelanjutan.',
    desc: 'Model bisnis yang bertanggung jawab dan berorientasi jangka panjang, memberdayakan kreativitas generasi muda.',
    color: '#FF2F92',
    icon: '🚀',
  },
];

export function Section11Impact() {
  const ref = useRef<HTMLDivElement>(null);
  const isInView = useInView(ref, { once: false, amount: 0.2 });

  return (
    <div
      ref={ref}
      style={{
        minHeight: '100vh',
        background: '#0C0F1E',
        position: 'relative',
        overflow: 'hidden',
        display: 'flex',
        flexDirection: 'column',
        alignItems: 'center',
        justifyContent: 'center',
        padding: '60px 80px',
        fontFamily: "'Space Grotesk', sans-serif",
      }}
    >
      {/* Ambient particles represented by orbs */}
      <div style={{ position: 'absolute', top: -80, left: '20%', width: 300, height: 300, background: 'radial-gradient(circle, rgba(108,76,255,0.12) 0%, transparent 70%)', borderRadius: '50%', animation: 'float 7s ease-in-out infinite' }} />
      <div style={{ position: 'absolute', bottom: -80, right: '20%', width: 250, height: 250, background: 'radial-gradient(circle, rgba(255,47,146,0.1) 0%, transparent 70%)', borderRadius: '50%', animation: 'float 6s ease-in-out infinite 2s' }} />

      <div style={{ position: 'relative', zIndex: 2, width: '100%', maxWidth: 1000 }}>
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          animate={isInView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.6 }}
          style={{ textAlign: 'center', marginBottom: 60 }}
        >
          <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 10, marginBottom: 14 }}>
            <span style={{ fontSize: 11, color: '#6C4CFF', letterSpacing: '0.2em', textTransform: 'uppercase', fontWeight: 600 }}>Section 11</span>
            <span style={{ width: 40, height: 1, background: 'rgba(108,76,255,0.5)' }} />
            <span style={{ fontSize: 11, color: 'rgba(234,244,255,0.4)', letterSpacing: '0.15em', textTransform: 'uppercase' }}>Impact Statement</span>
          </div>
          <h2 style={{
            fontFamily: "'Orbitron', monospace",
            fontSize: 'clamp(28px, 4vw, 52px)',
            fontWeight: 700,
            background: 'linear-gradient(135deg, #6C4CFF, #FF2F92)',
            WebkitBackgroundClip: 'text',
            WebkitTextFillColor: 'transparent',
            backgroundClip: 'text',
          }}>
            Dampak Nyata
          </h2>
        </motion.div>

        {/* Impact statements */}
        <div style={{ display: 'flex', flexDirection: 'column', gap: 28 }}>
          {IMPACTS.map((item, i) => (
            <motion.div
              key={i}
              initial={{ opacity: 0, x: i % 2 === 0 ? -60 : 60 }}
              animate={isInView ? { opacity: 1, x: 0 } : {}}
              transition={{ duration: 0.7, delay: 0.15 + i * 0.15 }}
              style={{
                background: 'rgba(255,255,255,0.025)',
                backdropFilter: 'blur(20px)',
                border: `1px solid ${item.color}25`,
                borderRadius: 24,
                padding: '32px 40px',
                position: 'relative',
                overflow: 'hidden',
                display: 'flex',
                alignItems: 'center',
                gap: 28,
              }}
            >
              {/* Left accent */}
              <div style={{ position: 'absolute', left: 0, top: 0, bottom: 0, width: 3, background: `linear-gradient(to bottom, transparent, ${item.color}, transparent)` }} />

              {/* Icon */}
              <div style={{
                fontSize: 44,
                flexShrink: 0,
                filter: `drop-shadow(0 0 15px ${item.color}80)`,
              }}>
                {item.icon}
              </div>

              {/* Text */}
              <div style={{ flex: 1 }}>
                <p style={{
                  fontFamily: "'Orbitron', monospace",
                  fontSize: 'clamp(18px, 2.5vw, 28px)',
                  fontWeight: 700,
                  marginBottom: 10,
                  lineHeight: 1.3,
                }}>
                  <span style={{ color: 'rgba(234,244,255,0.6)', fontWeight: 400 }}>{item.text} </span>
                  <span style={{
                    background: `linear-gradient(135deg, ${item.color}, ${item.color}CC)`,
                    WebkitBackgroundClip: 'text',
                    WebkitTextFillColor: 'transparent',
                    backgroundClip: 'text',
                    textShadow: 'none',
                  }}>
                    {item.highlight}
                  </span>
                </p>
                <p style={{ fontSize: 14, color: 'rgba(234,244,255,0.5)', lineHeight: 1.7 }}>{item.desc}</p>
              </div>

              {/* BG glow */}
              <div style={{ position: 'absolute', right: -30, top: '50%', transform: 'translateY(-50%)', width: 200, height: 200, background: `radial-gradient(circle, ${item.color}12, transparent)`, borderRadius: '50%', pointerEvents: 'none' }} />
            </motion.div>
          ))}
        </div>
      </div>
    </div>
  );
}
