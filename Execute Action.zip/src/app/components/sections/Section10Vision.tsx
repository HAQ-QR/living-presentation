import { motion, useInView } from 'motion/react';
import { useRef } from 'react';

export function Section10Vision() {
  const ref = useRef<HTMLDivElement>(null);
  const isInView = useInView(ref, { once: false, amount: 0.3 });

  return (
    <div
      ref={ref}
      style={{
        minHeight: '100vh',
        background: '#0C0F1E',
        position: 'relative',
        overflow: 'hidden',
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'center',
        fontFamily: "'Space Grotesk', sans-serif",
      }}
    >
      {/* Cinematic light burst */}
      <div style={{
        position: 'absolute',
        top: '50%',
        left: '50%',
        transform: 'translate(-50%, -50%)',
        width: '100%',
        height: '100%',
        background: 'radial-gradient(ellipse at center, rgba(108,76,255,0.18) 0%, rgba(0,247,255,0.05) 40%, transparent 70%)',
        pointerEvents: 'none',
      }} />

      {/* Light rays */}
      {[0, 45, 90, 135, 180, 225, 270, 315].map((angle, i) => (
        <div key={i} style={{
          position: 'absolute',
          top: '50%',
          left: '50%',
          width: '60vw',
          height: 1,
          background: `linear-gradient(90deg, rgba(108,76,255,0.15), transparent)`,
          transform: `rotate(${angle}deg)`,
          transformOrigin: '0 0',
          pointerEvents: 'none',
          opacity: 0.5,
        }} />
      ))}

      {/* Ambient orbs */}
      <div style={{ position: 'absolute', top: '20%', left: '15%', width: 200, height: 200, background: 'radial-gradient(circle, rgba(108,76,255,0.2) 0%, transparent 70%)', borderRadius: '50%', animation: 'float 6s ease-in-out infinite' }} />
      <div style={{ position: 'absolute', bottom: '20%', right: '15%', width: 150, height: 150, background: 'radial-gradient(circle, rgba(0,247,255,0.15) 0%, transparent 70%)', borderRadius: '50%', animation: 'float 5s ease-in-out infinite 1s' }} />
      <div style={{ position: 'absolute', top: '30%', right: '20%', width: 100, height: 100, background: 'radial-gradient(circle, rgba(255,47,146,0.12) 0%, transparent 70%)', borderRadius: '50%', animation: 'float 4s ease-in-out infinite 2s' }} />

      <div style={{ position: 'relative', zIndex: 2, textAlign: 'center', maxWidth: 760, padding: '0 40px' }}>
        <motion.div
          initial={{ opacity: 0, y: -10 }}
          animate={isInView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.6 }}
          style={{ display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 10, marginBottom: 36 }}
        >
          <span style={{ fontSize: 11, color: '#6C4CFF', letterSpacing: '0.2em', textTransform: 'uppercase', fontWeight: 600 }}>Section 10</span>
          <span style={{ width: 40, height: 1, background: 'rgba(108,76,255,0.5)' }} />
          <span style={{ fontSize: 11, color: 'rgba(234,244,255,0.4)', letterSpacing: '0.15em', textTransform: 'uppercase' }}>Visi</span>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, scale: 0.8 }}
          animate={isInView ? { opacity: 1, scale: 1 } : {}}
          transition={{ duration: 0.5, delay: 0.1 }}
          style={{
            fontSize: 40,
            marginBottom: 28,
            filter: 'drop-shadow(0 0 20px rgba(108,76,255,0.8))',
            animation: 'float 4s ease-in-out infinite',
          }}
        >
          🌟
        </motion.div>

        <motion.h2
          initial={{ opacity: 0, y: 30 }}
          animate={isInView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.8, delay: 0.2 }}
          style={{
            fontFamily: "'Orbitron', monospace",
            fontSize: 'clamp(22px, 3.5vw, 44px)',
            fontWeight: 700,
            background: 'linear-gradient(135deg, #EAF4FF 0%, #6C4CFF 40%, #00F7FF 100%)',
            WebkitBackgroundClip: 'text',
            WebkitTextFillColor: 'transparent',
            backgroundClip: 'text',
            lineHeight: 1.4,
            marginBottom: 36,
          }}
        >
          Menjadi hampers pilihan utama<br />pelajar Indonesia
        </motion.h2>

        <motion.p
          initial={{ opacity: 0, y: 20 }}
          animate={isInView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.8, delay: 0.4 }}
          style={{
            fontSize: 'clamp(15px, 1.8vw, 20px)',
            color: 'rgba(234,244,255,0.65)',
            lineHeight: 1.9,
            marginBottom: 52,
          }}
        >
          yang tidak hanya memberikan alat tulis,
          <br />
          tetapi juga{' '}
          <span style={{
            background: 'linear-gradient(135deg, #FF2F92, #6C4CFF)',
            WebkitBackgroundClip: 'text',
            WebkitTextFillColor: 'transparent',
            backgroundClip: 'text',
            fontWeight: 600,
          }}>
            semangat
          </span>{' '}
          dan{' '}
          <span style={{
            background: 'linear-gradient(135deg, #6C4CFF, #00F7FF)',
            WebkitBackgroundClip: 'text',
            WebkitTextFillColor: 'transparent',
            backgroundClip: 'text',
            fontWeight: 600,
          }}>
            inspirasi.
          </span>
        </motion.p>

        {/* Decorative line */}
        <motion.div
          initial={{ opacity: 0, scaleX: 0 }}
          animate={isInView ? { opacity: 1, scaleX: 1 } : {}}
          transition={{ duration: 1, delay: 0.6 }}
          style={{
            height: 1,
            background: 'linear-gradient(90deg, transparent, rgba(108,76,255,0.6), rgba(0,247,255,0.6), transparent)',
            margin: '0 auto',
            maxWidth: 400,
          }}
        />
      </div>
    </div>
  );
}
