import { motion, useInView } from 'motion/react';
import { useRef } from 'react';
import { BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer, Cell, CartesianGrid } from 'recharts';

const DATA = [
  { name: 'SMP Kls 7', value: 68, color: '#6C4CFF' },
  { name: 'SMP Kls 8', value: 72, color: '#7A5CFF' },
  { name: 'SMP Kls 9', value: 65, color: '#8B6CFF' },
  { name: 'SMA Kls 10', value: 85, color: '#00C8FF' },
  { name: 'SMA Kls 11', value: 92, color: '#00F7FF' },
  { name: 'SMA Kls 12', value: 78, color: '#00E0E8' },
];

const CustomTooltip = ({ active, payload, label }: any) => {
  if (active && payload && payload.length) {
    return (
      <div style={{
        background: 'rgba(12,15,30,0.95)',
        backdropFilter: 'blur(20px)',
        border: '1px solid rgba(0,247,255,0.3)',
        borderRadius: 12,
        padding: '10px 16px',
        fontFamily: "'Space Grotesk', sans-serif",
      }}>
        <div style={{ fontSize: 12, color: 'rgba(234,244,255,0.6)', marginBottom: 4 }}>{label}</div>
        <div style={{ fontSize: 18, fontWeight: 700, color: '#00F7FF', fontFamily: "'Orbitron', monospace" }}>{payload[0].value}%</div>
        <div style={{ fontSize: 11, color: 'rgba(234,244,255,0.4)' }}>Potensi Pasar</div>
      </div>
    );
  }
  return null;
};

export function Section07MarketAnalysis() {
  const ref = useRef<HTMLDivElement>(null);
  const isInView = useInView(ref, { once: false, amount: 0.2 });

  return (
    <div
      ref={ref}
      style={{
        minHeight: '100vh',
        background: '#0C0F1E',
        position: 'relative',
        overflow: 'hidden',
        display: 'flex',
        flexDirection: 'column',
        alignItems: 'center',
        justifyContent: 'center',
        padding: '60px 80px',
        fontFamily: "'Space Grotesk', sans-serif",
      }}
    >
      {/* BG */}
      <div style={{ position: 'absolute', bottom: -100, left: -100, width: 500, height: 500, background: 'radial-gradient(circle, rgba(0,247,255,0.08) 0%, transparent 70%)', borderRadius: '50%' }} />
      <div style={{ position: 'absolute', top: -100, right: -100, width: 400, height: 400, background: 'radial-gradient(circle, rgba(108,76,255,0.1) 0%, transparent 70%)', borderRadius: '50%' }} />

      <div style={{ position: 'relative', zIndex: 2, width: '100%', maxWidth: 1100 }}>
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          animate={isInView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.6 }}
          style={{ textAlign: 'center', marginBottom: 48 }}
        >
          <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 10, marginBottom: 14 }}>
            <span style={{ fontSize: 11, color: '#6C4CFF', letterSpacing: '0.2em', textTransform: 'uppercase', fontWeight: 600 }}>Section 07</span>
            <span style={{ width: 40, height: 1, background: 'rgba(108,76,255,0.5)' }} />
            <span style={{ fontSize: 11, color: 'rgba(234,244,255,0.4)', letterSpacing: '0.15em', textTransform: 'uppercase' }}>Analisis Pasar</span>
          </div>
          <h2 style={{
            fontFamily: "'Orbitron', monospace",
            fontSize: 'clamp(28px, 4vw, 52px)',
            fontWeight: 700,
            background: 'linear-gradient(135deg, #6C4CFF, #00F7FF)',
            WebkitBackgroundClip: 'text',
            WebkitTextFillColor: 'transparent',
            backgroundClip: 'text',
            marginBottom: 16,
          }}>
            Market Analysis
          </h2>
        </motion.div>

        {/* Stats row */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={isInView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.6, delay: 0.2 }}
          style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: 20, marginBottom: 44 }}
        >
          {[
            { label: 'Target', value: 'Pelajar SMP & SMA', icon: '🎯' },
            { label: 'Segmentasi Usia', value: '13 – 18 Tahun', icon: '📊' },
            { label: 'Potensi Pasar', value: 'Luas & Bertumbuh', icon: '📈' },
          ].map((s, i) => (
            <div key={i} style={{
              background: 'rgba(255,255,255,0.03)',
              backdropFilter: 'blur(20px)',
              border: '1px solid rgba(255,255,255,0.07)',
              borderRadius: 16,
              padding: '20px 24px',
              textAlign: 'center',
            }}>
              <div style={{ fontSize: 28, marginBottom: 8 }}>{s.icon}</div>
              <div style={{ fontSize: 11, color: 'rgba(234,244,255,0.4)', letterSpacing: '0.1em', textTransform: 'uppercase', marginBottom: 4 }}>{s.label}</div>
              <div style={{ fontSize: 15, fontWeight: 600, color: '#00F7FF' }}>{s.value}</div>
            </div>
          ))}
        </motion.div>

        {/* Chart */}
        <motion.div
          initial={{ opacity: 0, scale: 0.95 }}
          animate={isInView ? { opacity: 1, scale: 1 } : {}}
          transition={{ duration: 0.8, delay: 0.3 }}
          style={{
            background: 'rgba(255,255,255,0.02)',
            backdropFilter: 'blur(20px)',
            border: '1px solid rgba(255,255,255,0.06)',
            borderRadius: 24,
            padding: '36px 36px 24px',
            position: 'relative',
            overflow: 'hidden',
          }}
        >
          <div style={{ position: 'absolute', top: 0, left: 0, right: 0, height: 2, background: 'linear-gradient(90deg, transparent, #00F7FF, transparent)' }} />
          <div style={{ fontSize: 13, color: 'rgba(234,244,255,0.5)', marginBottom: 24, fontWeight: 500 }}>
            Potensi Penetrasi Pasar per Tingkat Kelas (%)
          </div>
          <ResponsiveContainer width="100%" height={280}>
            <BarChart data={DATA} barSize={36}>
              <CartesianGrid vertical={false} stroke="rgba(255,255,255,0.04)" />
              <XAxis
                dataKey="name"
                tick={{ fill: 'rgba(234,244,255,0.5)', fontSize: 11, fontFamily: "'Space Grotesk', sans-serif" }}
                axisLine={false}
                tickLine={false}
              />
              <YAxis
                tick={{ fill: 'rgba(234,244,255,0.4)', fontSize: 10 }}
                axisLine={false}
                tickLine={false}
                domain={[0, 100]}
                tickFormatter={(v) => `${v}%`}
              />
              <Tooltip content={<CustomTooltip />} cursor={{ fill: 'rgba(255,255,255,0.03)' }} />
              <Bar dataKey="value" radius={[8, 8, 0, 0]}>
                {DATA.map((entry, index) => (
                  <Cell
                    key={`cell-${index}`}
                    fill={entry.color}
                    style={{ filter: `drop-shadow(0 0 8px ${entry.color}80)` }}
                  />
                ))}
              </Bar>
            </BarChart>
          </ResponsiveContainer>
        </motion.div>
      </div>
    </div>
  );
}
