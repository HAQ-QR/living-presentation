import { motion, useInView } from 'motion/react';
import { useRef, useState } from 'react';

const TABS = [
  {
    id: 'product',
    label: 'Product',
    icon: '📦',
    color: '#6C4CFF',
    title: 'Hampers Estetik Berkualitas',
    desc: 'Thoughtful Beginning menghadirkan hampers alat tulis premium yang didesain dengan estetika minimalis modern. Setiap item dipilih dengan cermat untuk memenuhi kebutuhan belajar sehari-hari pelajar.',
    points: ['Notebook Premium Minimalis', 'Pulpen Estetik Smooth-write', 'Sticky Notes Pastel Series', 'Kartu Motivasi Personal'],
  },
  {
    id: 'price',
    label: 'Price',
    icon: '💰',
    color: '#00F7FF',
    title: 'Terjangkau untuk Pelajar',
    desc: 'Harga yang dirancang khusus agar dapat dijangkau oleh semua kalangan pelajar, dengan kualitas yang tidak mengorbankan estetika dan nilai emosional produk.',
    points: ['Harga Jual: Rp 120.000', 'Modal Produksi: Rp 90.000', 'Margin Keuntungan: 25%', 'Opsi diskon untuk pembelian massal'],
  },
  {
    id: 'place',
    label: 'Place',
    icon: '🏪',
    color: '#FF2F92',
    title: 'Online & Pemesanan Langsung',
    desc: 'Distribusi produk melalui berbagai saluran yang mudah diakses oleh pelajar modern, baik secara digital maupun tatap muka.',
    points: ['WhatsApp & Direct Order', 'Instagram Shop', 'Marketplace Digital', 'Pemesanan di Sekolah'],
  },
  {
    id: 'promotion',
    label: 'Promotion',
    icon: '📣',
    color: '#6C4CFF',
    title: 'Media Sosial & Rekomendasi',
    desc: 'Strategi promosi yang memanfaatkan kekuatan media sosial dan jaringan pertemanan untuk menjangkau target pasar secara organik dan efektif.',
    points: ['Konten Instagram & TikTok', 'Word of Mouth Marketing', 'Giveaway & Kolaborasi', 'Review & Testimoni Pelanggan'],
  },
];

export function Section06Strategy4P() {
  const ref = useRef<HTMLDivElement>(null);
  const isInView = useInView(ref, { once: false, amount: 0.2 });
  const [activeTab, setActiveTab] = useState(0);

  const tab = TABS[activeTab];

  return (
    <div
      ref={ref}
      style={{
        minHeight: '100vh',
        background: '#0C0F1E',
        position: 'relative',
        overflow: 'hidden',
        display: 'flex',
        flexDirection: 'column',
        alignItems: 'center',
        justifyContent: 'center',
        padding: '60px 80px',
        fontFamily: "'Space Grotesk', sans-serif",
      }}
    >
      {/* BG */}
      <div style={{ position: 'absolute', top: '30%', left: '50%', transform: 'translateX(-50%)', width: 600, height: 400, background: 'radial-gradient(ellipse, rgba(108,76,255,0.1) 0%, transparent 70%)', pointerEvents: 'none' }} />

      <div style={{ position: 'relative', zIndex: 2, width: '100%', maxWidth: 1100 }}>
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          animate={isInView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.6 }}
          style={{ textAlign: 'center', marginBottom: 48 }}
        >
          <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 10, marginBottom: 14 }}>
            <span style={{ fontSize: 11, color: '#6C4CFF', letterSpacing: '0.2em', textTransform: 'uppercase', fontWeight: 600 }}>Section 06</span>
            <span style={{ width: 40, height: 1, background: 'rgba(108,76,255,0.5)' }} />
            <span style={{ fontSize: 11, color: 'rgba(234,244,255,0.4)', letterSpacing: '0.15em', textTransform: 'uppercase' }}>Marketing Strategy</span>
          </div>
          <h2 style={{
            fontFamily: "'Orbitron', monospace",
            fontSize: 'clamp(28px, 4vw, 52px)',
            fontWeight: 700,
            background: 'linear-gradient(135deg, #6C4CFF, #00F7FF)',
            WebkitBackgroundClip: 'text',
            WebkitTextFillColor: 'transparent',
            backgroundClip: 'text',
          }}>
            Strategi 4P
          </h2>
        </motion.div>

        {/* Tabs */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={isInView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.6, delay: 0.2 }}
          style={{ display: 'flex', gap: 0, marginBottom: 32, justifyContent: 'center' }}
        >
          {TABS.map((t, i) => (
            <button
              key={t.id}
              onClick={() => setActiveTab(i)}
              style={{
                position: 'relative',
                padding: '14px 32px',
                background: 'transparent',
                border: 'none',
                cursor: 'pointer',
                fontFamily: "'Orbitron', monospace",
                fontSize: 13,
                fontWeight: 600,
                letterSpacing: '0.1em',
                color: activeTab === i ? t.color : 'rgba(234,244,255,0.35)',
                transition: 'all 0.3s ease',
                textShadow: activeTab === i ? `0 0 15px ${t.color}` : 'none',
              }}
            >
              <span style={{ marginRight: 8 }}>{t.icon}</span>
              {t.label}
              {/* Underline */}
              <div style={{
                position: 'absolute',
                bottom: 0,
                left: activeTab === i ? 0 : '50%',
                right: activeTab === i ? 0 : '50%',
                height: 2,
                background: `linear-gradient(90deg, transparent, ${t.color}, transparent)`,
                boxShadow: activeTab === i ? `0 0 10px ${t.color}` : 'none',
                transition: 'all 0.4s cubic-bezier(0.4, 0, 0.2, 1)',
              }} />
            </button>
          ))}
        </motion.div>

        {/* Tab Content */}
        <motion.div
          key={activeTab}
          initial={{ opacity: 0, y: 20, scale: 0.97 }}
          animate={{ opacity: 1, y: 0, scale: 1 }}
          transition={{ duration: 0.5, ease: 'easeOut' }}
          style={{
            background: 'rgba(255,255,255,0.03)',
            backdropFilter: 'blur(20px)',
            border: `1px solid ${tab.color}30`,
            borderRadius: 24,
            padding: '44px 52px',
            position: 'relative',
            overflow: 'hidden',
          }}
        >
          <div style={{ position: 'absolute', top: 0, left: 0, right: 0, height: 2, background: `linear-gradient(90deg, transparent, ${tab.color}, transparent)` }} />
          <div style={{ position: 'absolute', top: -80, right: -80, width: 300, height: 300, background: `radial-gradient(circle, ${tab.color}15 0%, transparent 70%)`, borderRadius: '50%' }} />

          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 60, position: 'relative', zIndex: 1 }}>
            <div>
              <div style={{ fontSize: 52, marginBottom: 20 }}>{tab.icon}</div>
              <h3 style={{
                fontFamily: "'Orbitron', monospace",
                fontSize: 'clamp(18px, 2.5vw, 28px)',
                fontWeight: 700,
                color: tab.color,
                marginBottom: 16,
                textShadow: `0 0 20px ${tab.color}60`,
              }}>
                {tab.title}
              </h3>
              <p style={{ fontSize: 15, color: 'rgba(234,244,255,0.65)', lineHeight: 1.8 }}>
                {tab.desc}
              </p>
            </div>
            <div>
              <div style={{ fontSize: 12, color: 'rgba(234,244,255,0.4)', letterSpacing: '0.15em', textTransform: 'uppercase', marginBottom: 20, fontWeight: 600 }}>Key Points</div>
              <div style={{ display: 'flex', flexDirection: 'column', gap: 14 }}>
                {tab.points.map((pt, j) => (
                  <motion.div
                    key={j}
                    initial={{ opacity: 0, x: 20 }}
                    animate={{ opacity: 1, x: 0 }}
                    transition={{ delay: j * 0.08 }}
                    style={{ display: 'flex', alignItems: 'center', gap: 12 }}
                  >
                    <div style={{ width: 8, height: 8, borderRadius: '50%', background: tab.color, boxShadow: `0 0 8px ${tab.color}`, flexShrink: 0 }} />
                    <span style={{ fontSize: 15, color: 'rgba(234,244,255,0.8)' }}>{pt}</span>
                  </motion.div>
                ))}
              </div>
            </div>
          </div>
        </motion.div>
      </div>
    </div>
  );
}
