import { motion, useInView } from 'motion/react';
import { useRef } from 'react';

export function Section12Closing() {
  const ref = useRef<HTMLDivElement>(null);
  const isInView = useInView(ref, { once: false, amount: 0.3 });

  return (
    <div
      ref={ref}
      style={{
        minHeight: '100vh',
        background: '#0C0F1E',
        position: 'relative',
        overflow: 'hidden',
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'center',
        fontFamily: "'Space Grotesk', sans-serif",
      }}
    >
      {/* Energy flare bg */}
      <div style={{
        position: 'absolute',
        top: '50%',
        left: '50%',
        transform: 'translate(-50%, -50%)',
        width: 900,
        height: 900,
        background: 'radial-gradient(circle, rgba(108,76,255,0.2) 0%, rgba(0,247,255,0.05) 35%, transparent 65%)',
        borderRadius: '50%',
        animation: 'heroPulse 5s ease-in-out infinite',
      }} />

      {/* Burst rays */}
      {Array.from({ length: 12 }).map((_, i) => (
        <div key={i} style={{
          position: 'absolute',
          top: '50%',
          left: '50%',
          width: '50vw',
          height: '1px',
          background: `linear-gradient(90deg, rgba(108,76,255,${0.12 - i * 0.005}), transparent)`,
          transform: `rotate(${i * 30}deg)`,
          transformOrigin: '0 0',
          pointerEvents: 'none',
        }} />
      ))}

      {/* Corner accents */}
      <div style={{ position: 'absolute', top: 40, left: 40, width: 60, height: 60, borderTop: '2px solid rgba(108,76,255,0.5)', borderLeft: '2px solid rgba(108,76,255,0.5)', borderRadius: '4px 0 0 0' }} />
      <div style={{ position: 'absolute', top: 40, right: 40, width: 60, height: 60, borderTop: '2px solid rgba(0,247,255,0.5)', borderRight: '2px solid rgba(0,247,255,0.5)', borderRadius: '0 4px 0 0' }} />
      <div style={{ position: 'absolute', bottom: 40, left: 40, width: 60, height: 60, borderBottom: '2px solid rgba(0,247,255,0.5)', borderLeft: '2px solid rgba(0,247,255,0.5)', borderRadius: '0 0 0 4px' }} />
      <div style={{ position: 'absolute', bottom: 40, right: 40, width: 60, height: 60, borderBottom: '2px solid rgba(108,76,255,0.5)', borderRight: '2px solid rgba(108,76,255,0.5)', borderRadius: '0 0 4px 0' }} />

      {/* Floating orbs */}
      {[
        { x: '15%', y: '25%', size: 80, color: 'rgba(108,76,255,0.2)', delay: 0 },
        { x: '80%', y: '20%', size: 60, color: 'rgba(0,247,255,0.15)', delay: 1 },
        { x: '10%', y: '75%', size: 50, color: 'rgba(255,47,146,0.12)', delay: 2 },
        { x: '85%', y: '70%', size: 70, color: 'rgba(108,76,255,0.15)', delay: 1.5 },
      ].map((orb, i) => (
        <div key={i} style={{
          position: 'absolute',
          left: orb.x,
          top: orb.y,
          width: orb.size,
          height: orb.size,
          background: `radial-gradient(circle, ${orb.color}, transparent)`,
          borderRadius: '50%',
          animation: `float ${4 + i}s ease-in-out infinite ${orb.delay}s`,
        }} />
      ))}

      {/* Main content */}
      <div style={{ position: 'relative', zIndex: 2, textAlign: 'center', maxWidth: 800, padding: '0 40px' }}>

        {/* Section label */}
        <motion.div
          initial={{ opacity: 0 }}
          animate={isInView ? { opacity: 1 } : {}}
          transition={{ duration: 0.6 }}
          style={{ display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 10, marginBottom: 40 }}
        >
          <span style={{ width: 60, height: 1, background: 'linear-gradient(90deg, transparent, rgba(108,76,255,0.5))' }} />
          <span style={{ fontSize: 11, color: 'rgba(234,244,255,0.3)', letterSpacing: '0.2em', textTransform: 'uppercase' }}>Victory Screen</span>
          <span style={{ width: 60, height: 1, background: 'linear-gradient(90deg, rgba(108,76,255,0.5), transparent)' }} />
        </motion.div>

        {/* Main title */}
        <motion.h1
          initial={{ opacity: 0, scale: 0.7, y: 40 }}
          animate={isInView ? { opacity: 1, scale: 1, y: 0 } : {}}
          transition={{ duration: 1, delay: 0.2, type: 'spring', stiffness: 80 }}
          style={{
            fontFamily: "'Orbitron', monospace",
            fontSize: 'clamp(36px, 6vw, 80px)',
            fontWeight: 900,
            letterSpacing: '0.1em',
            background: 'linear-gradient(135deg, #6C4CFF 0%, #00F7FF 50%, #6C4CFF 100%)',
            backgroundSize: '200% auto',
            WebkitBackgroundClip: 'text',
            WebkitTextFillColor: 'transparent',
            backgroundClip: 'text',
            animation: 'sweepText 4s linear infinite',
            marginBottom: 24,
            textShadow: 'none',
          }}
        >
          THOUGHTFUL<br />BEGINNING
        </motion.h1>

        {/* Divider */}
        <motion.div
          initial={{ scaleX: 0 }}
          animate={isInView ? { scaleX: 1 } : {}}
          transition={{ duration: 0.8, delay: 0.6 }}
          style={{ height: 1, background: 'linear-gradient(90deg, transparent, rgba(108,76,255,0.7), rgba(0,247,255,0.7), transparent)', margin: '28px auto', maxWidth: 400 }}
        />

        <motion.p
          initial={{ opacity: 0, y: 20 }}
          animate={isInView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.8, delay: 0.7 }}
          style={{
            fontSize: 'clamp(16px, 2vw, 22px)',
            color: 'rgba(234,244,255,0.7)',
            marginBottom: 10,
            letterSpacing: '0.05em',
          }}
        >
          Bukan Sekadar Hadiah.
        </motion.p>

        <motion.p
          initial={{ opacity: 0, y: 20 }}
          animate={isInView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.8, delay: 0.85 }}
          style={{
            fontSize: 'clamp(18px, 2.5vw, 28px)',
            fontWeight: 600,
            background: 'linear-gradient(135deg, #FF2F92, #6C4CFF, #00F7FF)',
            WebkitBackgroundClip: 'text',
            WebkitTextFillColor: 'transparent',
            backgroundClip: 'text',
            marginBottom: 60,
            letterSpacing: '0.03em',
          }}
        >
          Ini adalah Awal yang Penuh Makna.
        </motion.p>

        <motion.div
          initial={{ opacity: 0, scale: 0.8 }}
          animate={isInView ? { opacity: 1, scale: 1 } : {}}
          transition={{ duration: 0.8, delay: 1.1, type: 'spring' }}
        >
          <p style={{
            fontFamily: "'Orbitron', monospace",
            fontSize: 'clamp(18px, 3vw, 36px)',
            fontWeight: 700,
            color: '#EAF4FF',
            letterSpacing: '0.2em',
            textShadow: '0 0 30px rgba(234,244,255,0.3)',
          }}>
            Terima Kasih
          </p>

          {/* Sparkles */}
          <div style={{ display: 'flex', justifyContent: 'center', gap: 12, marginTop: 20 }}>
            {['✨', '🌟', '✨', '⭐', '✨'].map((s, i) => (
              <motion.span
                key={i}
                initial={{ opacity: 0, y: 10 }}
                animate={isInView ? { opacity: 1, y: 0 } : {}}
                transition={{ delay: 1.3 + i * 0.1 }}
                style={{ fontSize: 20, filter: 'drop-shadow(0 0 8px rgba(234,244,255,0.8))' }}
              >
                {s}
              </motion.span>
            ))}
          </div>
        </motion.div>

        {/* Bottom credit */}
        <motion.div
          initial={{ opacity: 0 }}
          animate={isInView ? { opacity: 1 } : {}}
          transition={{ duration: 1, delay: 1.6 }}
          style={{ marginTop: 60 }}
        >
          <p style={{ fontSize: 11, color: 'rgba(234,244,255,0.2)', letterSpacing: '0.2em', textTransform: 'uppercase' }}>
            Thoughtful Beginning · Hampers Alat Tulis Estetik · 2025
          </p>
        </motion.div>
      </div>
    </div>
  );
}
