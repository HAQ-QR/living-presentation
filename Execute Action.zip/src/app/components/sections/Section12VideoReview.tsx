import { motion } from 'motion/react';
import { Play, Volume2, Maximize2, Star, ThumbsUp, Eye } from 'lucide-react';

export function Section12VideoReview() {
  return (
    <div
      style={{
        minHeight: '100vh',
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'center',
        padding: '80px 32px 120px',
        position: 'relative',
        overflow: 'hidden',
      }}
    >
      {/* Decorative elements */}
      <motion.div
        initial={{ opacity: 0, scale: 0.8 }}
        animate={{ opacity: 1, scale: 1 }}
        transition={{ duration: 0.8, delay: 0.2 }}
        style={{
          position: 'absolute',
          top: '10%',
          left: '5%',
          width: 400,
          height: 400,
          borderRadius: '50%',
          background: 'radial-gradient(circle, rgba(108,76,255,0.15) 0%, transparent 70%)',
          filter: 'blur(60px)',
          pointerEvents: 'none',
        }}
      />
      <motion.div
        initial={{ opacity: 0, scale: 0.8 }}
        animate={{ opacity: 1, scale: 1 }}
        transition={{ duration: 0.8, delay: 0.4 }}
        style={{
          position: 'absolute',
          bottom: '10%',
          right: '5%',
          width: 350,
          height: 350,
          borderRadius: '50%',
          background: 'radial-gradient(circle, rgba(0,247,255,0.15) 0%, transparent 70%)',
          filter: 'blur(60px)',
          pointerEvents: 'none',
        }}
      />

      <div style={{ maxWidth: 1400, width: '100%', zIndex: 2 }}>
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.7 }}
          style={{ textAlign: 'center', marginBottom: 60 }}
        >
          <motion.div
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ duration: 0.6, delay: 0.2 }}
            style={{
              display: 'inline-block',
              padding: '8px 24px',
              background: 'linear-gradient(135deg, rgba(108,76,255,0.2), rgba(0,247,255,0.2))',
              border: '1px solid rgba(108,76,255,0.4)',
              borderRadius: 30,
              marginBottom: 24,
              backdropFilter: 'blur(10px)',
            }}
          >
            <span
              style={{
                fontFamily: "'Orbitron', monospace",
                fontSize: 14,
                color: '#00F7FF',
                letterSpacing: '0.2em',
                textTransform: 'uppercase',
                textShadow: '0 0 20px rgba(0,247,255,0.6)',
              }}
            >
              Video Review
            </span>
          </motion.div>

          <h2
            style={{
              fontFamily: "'Orbitron', monospace",
              fontSize: 56,
              fontWeight: 800,
              color: '#EAF4FF',
              marginBottom: 20,
              lineHeight: 1.2,
              background: 'linear-gradient(135deg, #6C4CFF 0%, #00F7FF 50%, #FF2F92 100%)',
              WebkitBackgroundClip: 'text',
              WebkitTextFillColor: 'transparent',
              backgroundClip: 'text',
            }}
          >
            Unboxing & Review
          </h2>

          <p
            style={{
              fontFamily: "'Space Grotesk', sans-serif",
              fontSize: 18,
              color: 'rgba(234,244,255,0.7)',
              maxWidth: 700,
              margin: '0 auto',
              lineHeight: 1.6,
            }}
          >
            Lihat pengalaman nyata menggunakan produk kami
          </p>
        </motion.div>

        {/* Video Container */}
        <div style={{ display: 'grid', gridTemplateColumns: '1fr', gap: 40 }}>
          {/* Main Video */}
          <motion.div
            initial={{ opacity: 0, y: 40 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, delay: 0.3 }}
            style={{ position: 'relative' }}
          >
            {/* Neon frame */}
            <div
              style={{
                position: 'absolute',
                inset: -3,
                background: 'linear-gradient(135deg, #6C4CFF, #00F7FF, #FF2F92, #6C4CFF)',
                borderRadius: 20,
                animation: 'neonBorderCycle 8s linear infinite',
                filter: 'blur(1px)',
              }}
            />

            {/* Video wrapper */}
            <div
              style={{
                position: 'relative',
                background: 'rgba(12,15,30,0.8)',
                backdropFilter: 'blur(20px)',
                borderRadius: 18,
                overflow: 'hidden',
                border: '1px solid rgba(108,76,255,0.3)',
              }}
            >
              {/* Video placeholder with overlay */}
              <div
                style={{
                  position: 'relative',
                  width: '100%',
                  paddingBottom: '56.25%', // 16:9 aspect ratio
                  background: 'linear-gradient(135deg, rgba(12,15,30,0.95), rgba(20,24,45,0.95))',
                  overflow: 'hidden',
                }}
              >
                {/* Background pattern */}
                <div
                  style={{
                    position: 'absolute',
                    inset: 0,
                    backgroundImage:
                      'linear-gradient(rgba(108,76,255,0.03) 1px, transparent 1px), linear-gradient(90deg, rgba(108,76,255,0.03) 1px, transparent 1px)',
                    backgroundSize: '30px 30px',
                    opacity: 0.5,
                  }}
                />

                {/* Video content - Placeholder for actual video */}
                <div
                  style={{
                    position: 'absolute',
                    inset: 0,
                    display: 'flex',
                    alignItems: 'center',
                    justifyContent: 'center',
                    flexDirection: 'column',
                    gap: 20,
                  }}
                >
                  {/* Video illustration */}
                  <motion.div
                    animate={{
                      y: [0, -10, 0],
                      rotateY: [0, 5, 0, -5, 0],
                    }}
                    transition={{
                      duration: 4,
                      repeat: Infinity,
                      ease: 'easeInOut',
                    }}
                    style={{
                      width: 300,
                      height: 200,
                      background: 'linear-gradient(135deg, rgba(108,76,255,0.2), rgba(0,247,255,0.2))',
                      borderRadius: 16,
                      border: '2px solid rgba(108,76,255,0.4)',
                      display: 'flex',
                      alignItems: 'center',
                      justifyContent: 'center',
                      position: 'relative',
                      overflow: 'hidden',
                    }}
                  >
                    {/* Hand icon illustration */}
                    <svg
                      width="120"
                      height="120"
                      viewBox="0 0 120 120"
                      fill="none"
                      style={{ opacity: 0.6 }}
                    >
                      <motion.path
                        d="M60 30 L60 50 M60 50 L70 40 M60 50 L50 40"
                        stroke="#6C4CFF"
                        strokeWidth="4"
                        strokeLinecap="round"
                        initial={{ pathLength: 0 }}
                        animate={{ pathLength: 1 }}
                        transition={{ duration: 2, repeat: Infinity }}
                      />
                      <motion.circle
                        cx="60"
                        cy="70"
                        r="15"
                        fill="rgba(108,76,255,0.3)"
                        stroke="#00F7FF"
                        strokeWidth="3"
                        animate={{
                          scale: [1, 1.1, 1],
                          opacity: [0.5, 0.8, 0.5],
                        }}
                        transition={{ duration: 2, repeat: Infinity }}
                      />
                      <text
                        x="60"
                        y="78"
                        textAnchor="middle"
                        fill="#00F7FF"
                        fontSize="14"
                        fontFamily="'Orbitron', monospace"
                      >
                        👋
                      </text>
                    </svg>

                    {/* Shimmer effect */}
                    <motion.div
                      animate={{ x: ['-100%', '200%'] }}
                      transition={{
                        duration: 3,
                        repeat: Infinity,
                        ease: 'linear',
                      }}
                      style={{
                        position: 'absolute',
                        inset: 0,
                        background:
                          'linear-gradient(90deg, transparent, rgba(255,255,255,0.1), transparent)',
                      }}
                    />
                  </motion.div>

                  {/* Play button */}
                  <motion.button
                    whileHover={{ scale: 1.1 }}
                    whileTap={{ scale: 0.95 }}
                    style={{
                      width: 80,
                      height: 80,
                      borderRadius: '50%',
                      background: 'linear-gradient(135deg, #6C4CFF, #00F7FF)',
                      border: 'none',
                      display: 'flex',
                      alignItems: 'center',
                      justifyContent: 'center',
                      cursor: 'none',
                      boxShadow:
                        '0 0 40px rgba(108,76,255,0.6), 0 0 80px rgba(0,247,255,0.4), inset 0 0 20px rgba(255,255,255,0.2)',
                    }}
                  >
                    <Play size={32} color="#0C0F1E" fill="#0C0F1E" style={{ marginLeft: 4 }} />
                  </motion.button>

                  <p
                    style={{
                      fontFamily: "'Space Grotesk', sans-serif",
                      fontSize: 16,
                      color: 'rgba(234,244,255,0.6)',
                      letterSpacing: '0.05em',
                    }}
                  >
                    Click to watch video review
                  </p>
                </div>

                {/* Video controls overlay */}
                <div
                  style={{
                    position: 'absolute',
                    bottom: 0,
                    left: 0,
                    right: 0,
                    padding: '16px 24px',
                    background: 'linear-gradient(to top, rgba(12,15,30,0.95), transparent)',
                    display: 'flex',
                    alignItems: 'center',
                    gap: 16,
                  }}
                >
                  <div
                    style={{
                      flex: 1,
                      height: 4,
                      background: 'rgba(108,76,255,0.2)',
                      borderRadius: 2,
                      overflow: 'hidden',
                    }}
                  >
                    <motion.div
                      animate={{ scaleX: [0, 0.3, 0] }}
                      transition={{ duration: 5, repeat: Infinity }}
                      style={{
                        height: '100%',
                        background: 'linear-gradient(90deg, #6C4CFF, #00F7FF)',
                        originX: 0,
                      }}
                    />
                  </div>
                  <Volume2 size={20} color="rgba(234,244,255,0.5)" />
                  <Maximize2 size={20} color="rgba(234,244,255,0.5)" />
                </div>
              </div>

              {/* Video info */}
              <div
                style={{
                  padding: '24px 32px',
                  background: 'rgba(12,15,30,0.5)',
                  borderTop: '1px solid rgba(108,76,255,0.2)',
                }}
              >
                <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
                  <div>
                    <h3
                      style={{
                        fontFamily: "'Orbitron', monospace",
                        fontSize: 22,
                        color: '#EAF4FF',
                        marginBottom: 8,
                      }}
                    >
                      Unboxing & First Impressions
                    </h3>
                    <p
                      style={{
                        fontFamily: "'Space Grotesk', sans-serif",
                        fontSize: 14,
                        color: 'rgba(234,244,255,0.6)',
                      }}
                    >
                      Pengalaman menggunakan produk secara langsung
                    </p>
                  </div>

                  <div style={{ display: 'flex', gap: 24, alignItems: 'center' }}>
                    <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
                      <Eye size={18} color="#00F7FF" />
                      <span
                        style={{
                          fontFamily: "'Space Grotesk', sans-serif",
                          fontSize: 14,
                          color: 'rgba(234,244,255,0.7)',
                        }}
                      >
                        12.5K
                      </span>
                    </div>
                    <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
                      <ThumbsUp size={18} color="#FF2F92" />
                      <span
                        style={{
                          fontFamily: "'Space Grotesk', sans-serif",
                          fontSize: 14,
                          color: 'rgba(234,244,255,0.7)',
                        }}
                      >
                        1.2K
                      </span>
                    </div>
                    <div style={{ display: 'flex', alignItems: 'center', gap: 4 }}>
                      {[...Array(5)].map((_, i) => (
                        <Star
                          key={i}
                          size={16}
                          color="#6C4CFF"
                          fill={i < 4 ? '#6C4CFF' : 'none'}
                        />
                      ))}
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </motion.div>

          {/* Feature highlights */}
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: 24 }}>
            {[
              {
                icon: '📦',
                title: 'Premium Unboxing',
                desc: 'Kemasan premium dan eksklusif',
                color: '#6C4CFF',
              },
              {
                icon: '✨',
                title: 'Quality Materials',
                desc: 'Bahan berkualitas tinggi',
                color: '#00F7FF',
              },
              {
                icon: '🎯',
                title: 'Perfect Design',
                desc: 'Desain yang sempurna',
                color: '#FF2F92',
              },
            ].map((item, idx) => (
              <motion.div
                key={idx}
                initial={{ opacity: 0, y: 30 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.6, delay: 0.5 + idx * 0.1 }}
                whileHover={{ y: -8 }}
                style={{
                  background: 'rgba(12,15,30,0.6)',
                  backdropFilter: 'blur(20px)',
                  border: `1px solid ${item.color}40`,
                  borderRadius: 16,
                  padding: 24,
                  textAlign: 'center',
                }}
              >
                <div style={{ fontSize: 40, marginBottom: 12 }}>{item.icon}</div>
                <h4
                  style={{
                    fontFamily: "'Orbitron', monospace",
                    fontSize: 16,
                    color: item.color,
                    marginBottom: 8,
                  }}
                >
                  {item.title}
                </h4>
                <p
                  style={{
                    fontFamily: "'Space Grotesk', sans-serif",
                    fontSize: 13,
                    color: 'rgba(234,244,255,0.6)',
                  }}
                >
                  {item.desc}
                </p>
              </motion.div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}
