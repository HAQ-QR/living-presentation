import { motion, useInView } from 'motion/react';
import { useRef, useEffect, useState } from 'react';

const BARS = [
  { label: 'Modal Produksi', value: 90000, max: 120000, color: '#6C4CFF', glow: 'rgba(108,76,255,0.6)', pct: 75 },
  { label: 'Harga Jual', value: 120000, max: 120000, color: '#00F7FF', glow: 'rgba(0,247,255,0.6)', pct: 100 },
  { label: 'Keuntungan', value: 30000, max: 120000, color: '#FF2F92', glow: 'rgba(255,47,146,0.6)', pct: 25 },
];

function useCountUp(target: number, duration: number, active: boolean) {
  const [val, setVal] = useState(0);
  useEffect(() => {
    if (!active) return;
    let start = 0;
    const step = target / (duration / 16);
    const timer = setInterval(() => {
      start += step;
      if (start >= target) { setVal(target); clearInterval(timer); }
      else setVal(Math.floor(start));
    }, 16);
    return () => clearInterval(timer);
  }, [active, target, duration]);
  return val;
}

function Counter({ target, active }: { target: number; active: boolean }) {
  const val = useCountUp(target, 1800, active);
  return <>{val.toLocaleString('id-ID')}</>;
}

export function Section05Financial() {
  const ref = useRef<HTMLDivElement>(null);
  const isInView = useInView(ref, { once: false, amount: 0.3 });
  const [animWidth, setAnimWidth] = useState(false);

  useEffect(() => {
    if (isInView) {
      setTimeout(() => setAnimWidth(true), 400);
    } else {
      setAnimWidth(false);
    }
  }, [isInView]);

  return (
    <div
      ref={ref}
      style={{
        minHeight: '100vh',
        background: '#0C0F1E',
        position: 'relative',
        overflow: 'hidden',
        display: 'flex',
        alignItems: 'center',
        fontFamily: "'Space Grotesk', sans-serif",
      }}
    >
      {/* BG */}
      <div style={{ position: 'absolute', top: -100, left: -100, width: 600, height: 600, background: 'radial-gradient(circle, rgba(108,76,255,0.1) 0%, transparent 70%)', borderRadius: '50%' }} />
      <div style={{ position: 'absolute', bottom: -100, right: -100, width: 400, height: 400, background: 'radial-gradient(circle, rgba(0,247,255,0.08) 0%, transparent 70%)', borderRadius: '50%' }} />

      <div style={{ width: '100%', maxWidth: 1200, margin: '0 auto', padding: '80px 80px', display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 80, alignItems: 'center', position: 'relative', zIndex: 2 }}>

        {/* Left: Progress Bars */}
        <div>
          <motion.div
            initial={{ opacity: 0, x: -30 }}
            animate={isInView ? { opacity: 1, x: 0 } : {}}
            transition={{ duration: 0.7 }}
          >
            <div style={{ display: 'flex', alignItems: 'center', gap: 10, marginBottom: 24 }}>
              <span style={{ fontSize: 11, color: '#6C4CFF', letterSpacing: '0.2em', textTransform: 'uppercase', fontWeight: 600 }}>Section 05</span>
              <span style={{ width: 40, height: 1, background: 'rgba(108,76,255,0.5)' }} />
              <span style={{ fontSize: 11, color: 'rgba(234,244,255,0.4)', letterSpacing: '0.15em', textTransform: 'uppercase' }}>Analisis Keuangan</span>
            </div>
            <h2 style={{
              fontFamily: "'Orbitron', monospace",
              fontSize: 'clamp(24px, 3.5vw, 44px)',
              fontWeight: 700,
              background: 'linear-gradient(135deg, #6C4CFF, #00F7FF)',
              WebkitBackgroundClip: 'text',
              WebkitTextFillColor: 'transparent',
              backgroundClip: 'text',
              marginBottom: 44,
              lineHeight: 1.2,
            }}>
              Financial<br />Analysis
            </h2>
          </motion.div>

          <div style={{ display: 'flex', flexDirection: 'column', gap: 32 }}>
            {BARS.map((b, i) => (
              <motion.div
                key={i}
                initial={{ opacity: 0, x: -40 }}
                animate={isInView ? { opacity: 1, x: 0 } : {}}
                transition={{ duration: 0.6, delay: 0.2 + i * 0.15 }}
              >
                <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: 10 }}>
                  <span style={{ fontSize: 14, color: 'rgba(234,244,255,0.8)', fontWeight: 500 }}>{b.label}</span>
                  <span style={{ fontSize: 14, color: b.color, fontWeight: 600 }}>
                    Rp {b.value.toLocaleString('id-ID')}
                  </span>
                </div>
                <div style={{
                  width: '100%',
                  height: 12,
                  background: 'rgba(255,255,255,0.05)',
                  borderRadius: 100,
                  overflow: 'hidden',
                  position: 'relative',
                }}>
                  <div style={{
                    position: 'absolute',
                    left: 0,
                    top: 0,
                    bottom: 0,
                    width: animWidth ? `${b.pct}%` : '0%',
                    background: `linear-gradient(90deg, ${b.color}80, ${b.color})`,
                    borderRadius: 100,
                    boxShadow: `0 0 15px ${b.glow}, 0 0 30px ${b.glow}`,
                    transition: 'width 1.2s cubic-bezier(0.4, 0, 0.2, 1)',
                  }} />
                  {/* Shimmer */}
                  {animWidth && (
                    <div style={{
                      position: 'absolute',
                      top: 0,
                      left: 0,
                      bottom: 0,
                      width: '100%',
                      background: 'linear-gradient(90deg, transparent 0%, rgba(255,255,255,0.2) 50%, transparent 100%)',
                      backgroundSize: '200% 100%',
                      animation: 'shimmerBar 2s linear infinite',
                      borderRadius: 100,
                    }} />
                  )}
                </div>
              </motion.div>
            ))}
          </div>

          <motion.p
            initial={{ opacity: 0 }}
            animate={isInView ? { opacity: 1 } : {}}
            transition={{ duration: 0.8, delay: 0.7 }}
            style={{ marginTop: 32, fontSize: 13, color: 'rgba(234,244,255,0.4)', lineHeight: 1.7, fontStyle: 'italic' }}
          >
            Margin sehat dan berkelanjutan untuk pengembangan usaha.
          </motion.p>
        </div>

        {/* Right: Big glowing numbers */}
        <div style={{ display: 'flex', flexDirection: 'column', gap: 28 }}>
          {BARS.map((b, i) => (
            <motion.div
              key={i}
              initial={{ opacity: 0, scale: 0.7 }}
              animate={isInView ? { opacity: 1, scale: 1 } : {}}
              transition={{ duration: 0.7, delay: 0.3 + i * 0.15, type: 'spring' }}
              style={{
                background: 'rgba(255,255,255,0.03)',
                backdropFilter: 'blur(20px)',
                border: `1px solid ${b.color}30`,
                borderRadius: 20,
                padding: '24px 32px',
                position: 'relative',
                overflow: 'hidden',
              }}
            >
              <div style={{ position: 'absolute', top: 0, left: 0, right: 0, height: 2, background: `linear-gradient(90deg, transparent, ${b.color}, transparent)` }} />
              <div style={{ fontSize: 12, color: 'rgba(234,244,255,0.5)', marginBottom: 6, letterSpacing: '0.1em', textTransform: 'uppercase' }}>{b.label}</div>
              <div style={{
                fontFamily: "'Orbitron', monospace",
                fontSize: 'clamp(22px, 2.8vw, 36px)',
                fontWeight: 700,
                color: b.color,
                textShadow: `0 0 20px ${b.glow}, 0 0 40px ${b.glow}`,
                lineHeight: 1.2,
              }}>
                Rp <Counter target={b.value} active={isInView} />
              </div>
              {/* glow bg */}
              <div style={{ position: 'absolute', right: -20, bottom: -20, width: 100, height: 100, background: `radial-gradient(circle, ${b.color}20, transparent)`, borderRadius: '50%' }} />
            </motion.div>
          ))}

          {/* Margin card */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={isInView ? { opacity: 1, y: 0 } : {}}
            transition={{ duration: 0.7, delay: 0.7 }}
            style={{
              background: 'linear-gradient(135deg, rgba(108,76,255,0.15), rgba(0,247,255,0.08))',
              border: '1px solid rgba(108,76,255,0.4)',
              borderRadius: 20,
              padding: '18px 32px',
              textAlign: 'center',
            }}
          >
            <span style={{ fontSize: 13, color: 'rgba(234,244,255,0.6)' }}>Profit Margin</span>
            <div style={{
              fontFamily: "'Orbitron', monospace",
              fontSize: 32,
              fontWeight: 900,
              background: 'linear-gradient(135deg, #00F7FF, #6C4CFF)',
              WebkitBackgroundClip: 'text',
              WebkitTextFillColor: 'transparent',
              backgroundClip: 'text',
            }}>
              25%
            </div>
          </motion.div>
        </div>
      </div>
    </div>
  );
}
