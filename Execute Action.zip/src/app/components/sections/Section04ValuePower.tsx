import { motion, useInView } from 'motion/react';
import { useRef, useState } from 'react';

const VALUES = [
  {
    icon: '⚙️',
    title: 'Fungsional',
    desc: 'Alat tulis berkualitas yang mendukung produktivitas belajar setiap hari.',
    color: '#6C4CFF',
    glow: 'rgba(108,76,255,0.4)',
  },
  {
    icon: '✨',
    title: 'Estetik',
    desc: 'Desain yang indah dan minimalis, membuat belajar terasa lebih menyenangkan.',
    color: '#00F7FF',
    glow: 'rgba(0,247,255,0.4)',
  },
  {
    icon: '💛',
    title: 'Emosional',
    desc: 'Lebih dari sekadar produk — sebuah ekspresi perhatian dan dukungan yang tulus.',
    color: '#FF2F92',
    glow: 'rgba(255,47,146,0.4)',
  },
  {
    icon: '💎',
    title: 'Terjangkau',
    desc: 'Harga yang ramah di kantong pelajar tanpa mengorbankan kualitas dan nilai.',
    color: '#6C4CFF',
    glow: 'rgba(108,76,255,0.4)',
  },
];

export function Section04ValuePower() {
  const ref = useRef<HTMLDivElement>(null);
  const isInView = useInView(ref, { once: false, amount: 0.2 });
  const [hovered, setHovered] = useState<number | null>(null);

  return (
    <div
      ref={ref}
      style={{
        minHeight: '100vh',
        background: '#0C0F1E',
        position: 'relative',
        overflow: 'hidden',
        display: 'flex',
        flexDirection: 'column',
        alignItems: 'center',
        justifyContent: 'center',
        padding: '60px 80px',
        fontFamily: "'Space Grotesk', sans-serif",
      }}
    >
      {/* BG orbs */}
      <div style={{ position: 'absolute', top: -150, right: -150, width: 500, height: 500, background: 'radial-gradient(circle, rgba(0,247,255,0.08) 0%, transparent 70%)', borderRadius: '50%' }} />
      <div style={{ position: 'absolute', bottom: -150, left: -150, width: 500, height: 500, background: 'radial-gradient(circle, rgba(255,47,146,0.08) 0%, transparent 70%)', borderRadius: '50%' }} />

      <div style={{ position: 'relative', zIndex: 2, width: '100%', maxWidth: 1100 }}>
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          animate={isInView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.6 }}
          style={{ textAlign: 'center', marginBottom: 60 }}
        >
          <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 10, marginBottom: 16 }}>
            <span style={{ fontSize: 11, color: '#6C4CFF', letterSpacing: '0.2em', textTransform: 'uppercase', fontWeight: 600 }}>Section 04</span>
            <span style={{ width: 40, height: 1, background: 'rgba(108,76,255,0.5)' }} />
            <span style={{ fontSize: 11, color: 'rgba(234,244,255,0.4)', letterSpacing: '0.15em', textTransform: 'uppercase' }}>Value Power System</span>
          </div>
          <h2 style={{
            fontFamily: "'Orbitron', monospace",
            fontSize: 'clamp(28px, 4vw, 52px)',
            fontWeight: 700,
            background: 'linear-gradient(135deg, #6C4CFF, #00F7FF)',
            WebkitBackgroundClip: 'text',
            WebkitTextFillColor: 'transparent',
            backgroundClip: 'text',
            marginBottom: 8,
          }}>
            Nilai Inti Produk
          </h2>
        </motion.div>

        {/* 4 Power Cards */}
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(2, 1fr)', gap: 24, marginBottom: 52 }}>
          {VALUES.map((v, i) => (
            <motion.div
              key={i}
              initial={{ opacity: 0, y: 40, scale: 0.9 }}
              animate={isInView ? { opacity: 1, y: 0, scale: 1 } : {}}
              transition={{ duration: 0.6, delay: 0.1 + i * 0.12 }}
              onMouseEnter={() => setHovered(i)}
              onMouseLeave={() => setHovered(null)}
              style={{
                position: 'relative',
                background: 'rgba(255,255,255,0.03)',
                backdropFilter: 'blur(20px)',
                borderRadius: 24,
                padding: '36px 36px',
                cursor: 'pointer',
                transform: hovered === i ? 'scale(1.03) translateY(-2px)' : 'scale(1)',
                transition: 'all 0.3s cubic-bezier(0.4, 0, 0.2, 1)',
                overflow: 'hidden',
              }}
            >
              {/* Animated neon border via gradient border */}
              <div style={{
                position: 'absolute',
                inset: 0,
                borderRadius: 24,
                padding: 1,
                background: hovered === i
                  ? `linear-gradient(135deg, ${v.color}, ${i % 2 === 0 ? '#00F7FF' : '#6C4CFF'})`
                  : 'linear-gradient(135deg, rgba(108,76,255,0.3), rgba(255,255,255,0.05))',
                WebkitMask: 'linear-gradient(#fff 0 0) content-box, linear-gradient(#fff 0 0)',
                WebkitMaskComposite: 'xor',
                maskComposite: 'exclude',
                transition: 'all 0.4s ease',
                animation: `neonBorderCycle ${3 + i * 0.5}s linear infinite`,
              }} />

              {/* Glow background */}
              {hovered === i && (
                <div style={{
                  position: 'absolute',
                  inset: 0,
                  background: `radial-gradient(circle at 30% 30%, ${v.glow} 0%, transparent 60%)`,
                  borderRadius: 24,
                  pointerEvents: 'none',
                }} />
              )}

              <div style={{ position: 'relative', zIndex: 1 }}>
                <div style={{
                  fontSize: 48,
                  marginBottom: 18,
                  filter: hovered === i ? `drop-shadow(0 0 20px ${v.color})` : 'none',
                  transition: 'filter 0.3s',
                }}>
                  {v.icon}
                </div>
                <h3 style={{
                  fontFamily: "'Orbitron', monospace",
                  fontSize: 24,
                  fontWeight: 700,
                  color: hovered === i ? v.color : '#EAF4FF',
                  marginBottom: 12,
                  transition: 'color 0.3s',
                  textShadow: hovered === i ? `0 0 20px ${v.color}` : 'none',
                }}>
                  {v.title}
                </h3>
                <p style={{ fontSize: 14, color: 'rgba(234,244,255,0.6)', lineHeight: 1.7 }}>
                  {v.desc}
                </p>
              </div>
            </motion.div>
          ))}
        </div>

        {/* Bottom tagline */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={isInView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.8, delay: 0.6 }}
          style={{ textAlign: 'center' }}
        >
          <p style={{
            fontFamily: "'Orbitron', monospace",
            fontSize: 'clamp(16px, 2vw, 24px)',
            color: 'rgba(234,244,255,0.5)',
            letterSpacing: '0.08em',
          }}>
            Bukan hanya produk.{' '}
            <span style={{
              background: 'linear-gradient(135deg, #FF2F92, #6C4CFF)',
              WebkitBackgroundClip: 'text',
              WebkitTextFillColor: 'transparent',
              backgroundClip: 'text',
            }}>
              Ini adalah pengalaman.
            </span>
          </p>
        </motion.div>
      </div>
    </div>
  );
}
