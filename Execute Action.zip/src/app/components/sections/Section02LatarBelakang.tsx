import { motion, useInView } from 'motion/react';
import { useRef } from 'react';

const lines = [
  'Di era modern, pelajar tidak hanya',
  'membutuhkan alat tulis.',
  '',
  'Mereka membutuhkan motivasi.',
  '',
  'Hadiah bukan sekadar barang.',
  'Hadiah adalah simbol perhatian,',
  'doa, dan dukungan.',
  '',
  'Thoughtful Beginning hadir sebagai',
  'hampers alat tulis estetik yang',
  'memberikan makna di setiap detailnya.',
];

export function Section02LatarBelakang() {
  const ref = useRef<HTMLDivElement>(null);
  const isInView = useInView(ref, { once: false, amount: 0.3 });

  return (
    <div
      ref={ref}
      style={{
        minHeight: '100vh',
        background: '#0C0F1E',
        position: 'relative',
        overflow: 'hidden',
        display: 'flex',
        alignItems: 'center',
        fontFamily: "'Space Grotesk', sans-serif",
      }}
    >
      {/* BG orbs */}
      <div style={{ position: 'absolute', top: -100, left: -100, width: 600, height: 600, background: 'radial-gradient(circle, rgba(108,76,255,0.12) 0%, transparent 70%)', borderRadius: '50%' }} />
      <div style={{ position: 'absolute', bottom: -100, right: -100, width: 400, height: 400, background: 'radial-gradient(circle, rgba(0,247,255,0.08) 0%, transparent 70%)', borderRadius: '50%' }} />

      <div style={{ width: '100%', maxWidth: 1300, margin: '0 auto', padding: '80px 80px', display: 'grid', gridTemplateColumns: '60fr 40fr', gap: 80, alignItems: 'center', position: 'relative', zIndex: 2 }}>

        {/* Left: Text */}
        <div>
          <motion.div
            initial={{ opacity: 0, x: -20 }}
            animate={isInView ? { opacity: 1, x: 0 } : {}}
            transition={{ duration: 0.6 }}
            style={{
              display: 'inline-flex',
              alignItems: 'center',
              gap: 8,
              marginBottom: 32,
            }}
          >
            <span style={{ fontSize: 11, color: '#6C4CFF', letterSpacing: '0.2em', textTransform: 'uppercase', fontWeight: 600 }}>Section 02</span>
            <span style={{ width: 40, height: 1, background: 'rgba(108,76,255,0.5)' }} />
            <span style={{ fontSize: 11, color: 'rgba(234,244,255,0.4)', letterSpacing: '0.15em', textTransform: 'uppercase' }}>Latar Belakang</span>
          </motion.div>

          {/* Glass card with narrative */}
          <motion.div
            initial={{ opacity: 0, y: 40 }}
            animate={isInView ? { opacity: 1, y: 0 } : {}}
            transition={{ duration: 0.8, delay: 0.2 }}
            style={{
              background: 'rgba(255,255,255,0.03)',
              backdropFilter: 'blur(20px)',
              border: '1px solid rgba(255,255,255,0.08)',
              borderRadius: 24,
              padding: '40px 44px',
              position: 'relative',
              overflow: 'hidden',
            }}
          >
            {/* Accent top border */}
            <div style={{ position: 'absolute', top: 0, left: 0, right: 0, height: 2, background: 'linear-gradient(90deg, transparent, #6C4CFF, #00F7FF, transparent)' }} />

            {lines.map((line, i) => (
              <motion.p
                key={i}
                initial={{ opacity: 0, x: -20 }}
                animate={isInView ? { opacity: 1, x: 0 } : {}}
                transition={{ duration: 0.5, delay: 0.3 + i * 0.06 }}
                style={{
                  fontSize: line === '' ? undefined : line.includes('Hadiah adalah') || line.includes('Mereka') || line.includes('membutuhkan motivasi') ? 18 : 16,
                  color: line === '' ? undefined : i === 3 || i === 1 ? 'rgba(0,247,255,0.9)' : 'rgba(234,244,255,0.75)',
                  lineHeight: 1.8,
                  marginBottom: line === '' ? 16 : 4,
                  fontWeight: i === 3 ? 600 : 400,
                }}
              >
                {line || '\u00A0'}
              </motion.p>
            ))}
          </motion.div>
        </div>

        {/* Right: Gift Box Illustration */}
        <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
          <motion.div
            initial={{ opacity: 0, scale: 0.7 }}
            animate={isInView ? { opacity: 1, scale: 1 } : {}}
            transition={{ duration: 1, delay: 0.4, type: 'spring', stiffness: 100 }}
          >
            <div style={{ position: 'relative', animation: 'float 5s ease-in-out infinite' }}>
              {/* Outer glow aura */}
              <div style={{
                position: 'absolute',
                inset: '-60px',
                background: 'radial-gradient(ellipse, rgba(108,76,255,0.4) 0%, rgba(0,247,255,0.15) 50%, transparent 70%)',
                borderRadius: '50%',
                animation: 'heroPulse 3s ease-in-out infinite',
              }} />

              {/* Expanding rings */}
              {[0, 1, 2].map(i => (
                <div key={i} style={{
                  position: 'absolute',
                  inset: `${-40 - i * 30}px`,
                  border: `1px solid rgba(108,76,255,${0.3 - i * 0.08})`,
                  borderRadius: '50%',
                  animation: `expandRing ${2.5 + i * 0.5}s ease-out infinite ${i * 0.8}s`,
                }} />
              ))}

              {/* Gift box container */}
              <div style={{ position: 'relative', width: 220, height: 260 }}>
                {/* Bow left */}
                <div style={{
                  position: 'absolute',
                  top: -10,
                  left: 30,
                  width: 75,
                  height: 45,
                  background: 'linear-gradient(135deg, rgba(0,247,255,0.8), rgba(0,247,255,0.4))',
                  borderRadius: '50% 50% 30% 70%',
                  transform: 'rotate(-35deg)',
                  boxShadow: '0 0 20px rgba(0,247,255,0.7)',
                }} />
                {/* Bow right */}
                <div style={{
                  position: 'absolute',
                  top: -10,
                  right: 30,
                  width: 75,
                  height: 45,
                  background: 'linear-gradient(135deg, rgba(0,247,255,0.4), rgba(0,247,255,0.8))',
                  borderRadius: '50% 50% 70% 30%',
                  transform: 'rotate(35deg)',
                  boxShadow: '0 0 20px rgba(0,247,255,0.7)',
                }} />

                {/* Bow knot */}
                <div style={{
                  position: 'absolute',
                  top: 0,
                  left: '50%',
                  transform: 'translateX(-50%)',
                  zIndex: 10,
                  width: 28,
                  height: 28,
                  background: 'radial-gradient(circle, #00F7FF, rgba(0,247,255,0.7))',
                  borderRadius: '50%',
                  boxShadow: '0 0 20px rgba(0,247,255,1), 0 0 40px rgba(0,247,255,0.5)',
                }} />

                {/* Lid */}
                <div style={{
                  position: 'absolute',
                  top: 28,
                  left: -12,
                  right: -12,
                  height: 52,
                  background: 'linear-gradient(135deg, #7C5CFF 0%, #FF3F9A 100%)',
                  borderRadius: '10px 10px 0 0',
                  boxShadow: '0 0 30px rgba(108,76,255,0.5), 0 0 50px rgba(255,47,146,0.2)',
                }}>
                  {/* Lid ribbon */}
                  <div style={{ position: 'absolute', top: 0, bottom: 0, left: '50%', transform: 'translateX(-50%)', width: 22, background: 'rgba(0,247,255,0.6)', boxShadow: '0 0 15px rgba(0,247,255,0.8)' }} />
                </div>

                {/* Body */}
                <div style={{
                  position: 'absolute',
                  top: 80,
                  left: 0,
                  right: 0,
                  bottom: 0,
                  background: 'linear-gradient(135deg, rgba(108,76,255,0.7) 0%, rgba(255,47,146,0.5) 100%)',
                  borderRadius: '0 0 14px 14px',
                  boxShadow: '0 20px 60px rgba(108,76,255,0.35), inset 0 0 30px rgba(255,255,255,0.05)',
                  border: '1px solid rgba(255,255,255,0.12)',
                  overflow: 'hidden',
                }}>
                  {/* Body ribbon vertical */}
                  <div style={{ position: 'absolute', top: 0, bottom: 0, left: '50%', transform: 'translateX(-50%)', width: 22, background: 'rgba(0,247,255,0.5)', boxShadow: '0 0 15px rgba(0,247,255,0.7)' }} />
                  {/* Body ribbon horizontal */}
                  <div style={{ position: 'absolute', left: 0, right: 0, top: '45%', height: 22, background: 'rgba(0,247,255,0.5)', boxShadow: '0 0 15px rgba(0,247,255,0.7)' }} />
                  {/* Shine */}
                  <div style={{ position: 'absolute', top: 10, left: 10, width: 30, height: 20, background: 'rgba(255,255,255,0.15)', borderRadius: 10, transform: 'rotate(-30deg)' }} />
                </div>

                {/* Shadow beneath */}
                <div style={{
                  position: 'absolute',
                  bottom: -20,
                  left: '50%',
                  transform: 'translateX(-50%)',
                  width: 180,
                  height: 20,
                  background: 'radial-gradient(ellipse, rgba(108,76,255,0.5) 0%, transparent 70%)',
                  filter: 'blur(8px)',
                }} />
              </div>
            </div>
          </motion.div>
        </div>
      </div>
    </div>
  );
}