import { motion, useInView } from 'motion/react';
import { useRef, useState } from 'react';

const ADVANTAGES = [
  { icon: '🎨', title: 'Desain Unik', desc: 'Setiap detail dirancang dengan estetika yang konsisten dan menawan, membedakan produk dari kompetitor.', color: '#6C4CFF', glow: 'rgba(108,76,255,0.5)' },
  { icon: '💰', title: 'Harga Ramah Pelajar', desc: 'Pricing strategy yang disesuaikan dengan daya beli pelajar tanpa mengorbankan kualitas produk.', color: '#00F7FF', glow: 'rgba(0,247,255,0.5)' },
  { icon: '❤️', title: 'Nilai Emosional Tinggi', desc: 'Bukan sekadar produk — sebuah pengalaman bermakna yang menginspirasi semangat belajar.', color: '#FF2F92', glow: 'rgba(255,47,146,0.5)' },
  { icon: '📦', title: 'Kemasan Estetik', desc: 'Packaging yang indah dan Instagram-worthy menjadi daya tarik tersendiri di era visual ini.', color: '#6C4CFF', glow: 'rgba(108,76,255,0.5)' },
];

export function Section09Competitive() {
  const ref = useRef<HTMLDivElement>(null);
  const isInView = useInView(ref, { once: false, amount: 0.2 });
  const [hovered, setHovered] = useState<number | null>(null);

  return (
    <div
      ref={ref}
      style={{
        minHeight: '100vh',
        background: '#0C0F1E',
        position: 'relative',
        overflow: 'hidden',
        display: 'flex',
        flexDirection: 'column',
        alignItems: 'center',
        justifyContent: 'center',
        padding: '60px 80px',
        fontFamily: "'Space Grotesk', sans-serif",
      }}
    >
      {/* BG */}
      <div style={{ position: 'absolute', top: -100, right: -100, width: 500, height: 500, background: 'radial-gradient(circle, rgba(0,247,255,0.07) 0%, transparent 70%)', borderRadius: '50%' }} />
      <div style={{ position: 'absolute', bottom: -100, left: -100, width: 500, height: 500, background: 'radial-gradient(circle, rgba(255,47,146,0.07) 0%, transparent 70%)', borderRadius: '50%' }} />

      <div style={{ position: 'relative', zIndex: 2, width: '100%', maxWidth: 1100 }}>
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          animate={isInView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.6 }}
          style={{ textAlign: 'center', marginBottom: 56 }}
        >
          <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 10, marginBottom: 14 }}>
            <span style={{ fontSize: 11, color: '#6C4CFF', letterSpacing: '0.2em', textTransform: 'uppercase', fontWeight: 600 }}>Section 09</span>
            <span style={{ width: 40, height: 1, background: 'rgba(108,76,255,0.5)' }} />
            <span style={{ fontSize: 11, color: 'rgba(234,244,255,0.4)', letterSpacing: '0.15em', textTransform: 'uppercase' }}>Competitive Edge</span>
          </div>
          <h2 style={{
            fontFamily: "'Orbitron', monospace",
            fontSize: 'clamp(28px, 4vw, 52px)',
            fontWeight: 700,
            background: 'linear-gradient(135deg, #6C4CFF, #00F7FF)',
            WebkitBackgroundClip: 'text',
            WebkitTextFillColor: 'transparent',
            backgroundClip: 'text',
          }}>
            Keunggulan Kompetitif
          </h2>
        </motion.div>

        {/* Cards */}
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(2, 1fr)', gap: 24 }}>
          {ADVANTAGES.map((a, i) => (
            <motion.div
              key={i}
              initial={{ opacity: 0, y: 40, scale: 0.92 }}
              animate={isInView ? { opacity: 1, y: 0, scale: 1 } : {}}
              transition={{ duration: 0.6, delay: 0.1 + i * 0.12 }}
              onMouseEnter={() => setHovered(i)}
              onMouseLeave={() => setHovered(null)}
              style={{
                background: 'rgba(255,255,255,0.03)',
                backdropFilter: 'blur(20px)',
                border: `1px solid ${hovered === i ? a.color + '60' : 'rgba(255,255,255,0.07)'}`,
                borderRadius: 24,
                padding: '36px 36px',
                cursor: 'pointer',
                transform: hovered === i ? 'scale(1.03) translateY(-4px)' : 'scale(1) translateY(0)',
                boxShadow: hovered === i ? `0 0 40px ${a.glow}, 0 20px 60px rgba(0,0,0,0.4)` : '0 4px 20px rgba(0,0,0,0.2)',
                transition: 'all 0.35s cubic-bezier(0.4, 0, 0.2, 1)',
                position: 'relative',
                overflow: 'hidden',
              }}
            >
              {/* Top border glow */}
              <div style={{ position: 'absolute', top: 0, left: 0, right: 0, height: 2, background: `linear-gradient(90deg, transparent, ${a.color}, transparent)`, opacity: hovered === i ? 1 : 0.3, transition: 'opacity 0.3s' }} />

              {/* BG glow on hover */}
              {hovered === i && (
                <div style={{ position: 'absolute', inset: 0, background: `radial-gradient(circle at 20% 20%, ${a.glow}25 0%, transparent 60%)`, pointerEvents: 'none' }} />
              )}

              <div style={{ position: 'relative', zIndex: 1, display: 'flex', gap: 20, alignItems: 'flex-start' }}>
                <div style={{
                  fontSize: 44,
                  flexShrink: 0,
                  filter: hovered === i ? `drop-shadow(0 0 15px ${a.color})` : 'none',
                  transition: 'filter 0.3s',
                }}>
                  {a.icon}
                </div>
                <div>
                  <h3 style={{
                    fontFamily: "'Orbitron', monospace",
                    fontSize: 20,
                    fontWeight: 700,
                    color: hovered === i ? a.color : '#EAF4FF',
                    marginBottom: 10,
                    transition: 'color 0.3s',
                    textShadow: hovered === i ? `0 0 20px ${a.glow}` : 'none',
                  }}>
                    {a.title}
                  </h3>
                  <p style={{ fontSize: 14, color: 'rgba(234,244,255,0.6)', lineHeight: 1.7 }}>
                    {a.desc}
                  </p>
                </div>
              </div>
            </motion.div>
          ))}
        </div>

        {/* Bottom badge */}
        <motion.div
          initial={{ opacity: 0 }}
          animate={isInView ? { opacity: 1 } : {}}
          transition={{ duration: 1, delay: 0.7 }}
          style={{ textAlign: 'center', marginTop: 48 }}
        >
          <div style={{
            display: 'inline-flex',
            alignItems: 'center',
            gap: 12,
            background: 'rgba(108,76,255,0.1)',
            border: '1px solid rgba(108,76,255,0.3)',
            borderRadius: 50,
            padding: '10px 24px',
          }}>
            <span style={{ fontSize: 16 }}>⚡</span>
            <span style={{ fontSize: 13, color: 'rgba(234,244,255,0.7)', letterSpacing: '0.08em' }}>
              Kombinasi unik yang sulit ditiru kompetitor
            </span>
          </div>
        </motion.div>
      </div>
    </div>
  );
}
