import { motion, useInView } from 'motion/react';
import { useRef } from 'react';

const NODES = [
  { month: 'Bulan 1', title: 'Persiapan & Desain', desc: 'Riset pasar, desain produk, dan persiapan bahan baku.', color: '#6C4CFF', icon: '🎨' },
  { month: 'Bulan 2', title: 'Produksi Awal', desc: 'Produksi batch pertama dan quality control produk.', color: '#8260FF', icon: '⚙️' },
  { month: 'Bulan 3', title: 'Peluncuran', desc: 'Grand launching produk secara online dan offline.', color: '#00D4FF', icon: '🚀' },
  { month: 'Bulan 4', title: 'Promosi Intensif', desc: 'Kampanye media sosial, kolaborasi, dan event promosi.', color: '#00F7FF', icon: '📣' },
  { month: 'Bulan 5', title: 'Evaluasi', desc: 'Analisis penjualan, feedback pelanggan, dan perbaikan.', color: '#FF6BB0', icon: '📊' },
  { month: 'Bulan 6', title: 'Pengembangan Varian Baru', desc: 'Ekspansi lini produk berdasarkan hasil evaluasi pasar.', color: '#FF2F92', icon: '✨' },
];

export function Section08Roadmap() {
  const ref = useRef<HTMLDivElement>(null);
  const isInView = useInView(ref, { once: false, amount: 0.15 });

  return (
    <div
      ref={ref}
      style={{
        minHeight: '100vh',
        background: '#0C0F1E',
        position: 'relative',
        overflow: 'hidden',
        display: 'flex',
        flexDirection: 'column',
        alignItems: 'center',
        justifyContent: 'center',
        padding: '60px 80px',
        fontFamily: "'Space Grotesk', sans-serif",
      }}
    >
      {/* BG */}
      <div style={{ position: 'absolute', top: '50%', left: '50%', transform: 'translate(-50%,-50%)', width: 600, height: 800, background: 'radial-gradient(ellipse, rgba(108,76,255,0.07) 0%, transparent 60%)', borderRadius: '50%', pointerEvents: 'none' }} />

      <div style={{ position: 'relative', zIndex: 2, width: '100%', maxWidth: 900 }}>
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          animate={isInView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.6 }}
          style={{ textAlign: 'center', marginBottom: 52 }}
        >
          <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 10, marginBottom: 14 }}>
            <span style={{ fontSize: 11, color: '#6C4CFF', letterSpacing: '0.2em', textTransform: 'uppercase', fontWeight: 600 }}>Section 08</span>
            <span style={{ width: 40, height: 1, background: 'rgba(108,76,255,0.5)' }} />
            <span style={{ fontSize: 11, color: 'rgba(234,244,255,0.4)', letterSpacing: '0.15em', textTransform: 'uppercase' }}>Development Plan</span>
          </div>
          <h2 style={{
            fontFamily: "'Orbitron', monospace",
            fontSize: 'clamp(28px, 4vw, 52px)',
            fontWeight: 700,
            background: 'linear-gradient(135deg, #6C4CFF, #00F7FF)',
            WebkitBackgroundClip: 'text',
            WebkitTextFillColor: 'transparent',
            backgroundClip: 'text',
          }}>
            Rencana Pengembangan
          </h2>
        </motion.div>

        {/* Timeline */}
        <div style={{ position: 'relative' }}>
          {/* Vertical line */}
          <motion.div
            initial={{ scaleY: 0 }}
            animate={isInView ? { scaleY: 1 } : {}}
            transition={{ duration: 1.5, delay: 0.3, ease: 'easeInOut' }}
            style={{
              position: 'absolute',
              left: '50%',
              top: 0,
              bottom: 0,
              width: 2,
              background: 'linear-gradient(to bottom, #6C4CFF, #00F7FF, #FF2F92)',
              transform: 'translateX(-50%)',
              transformOrigin: 'top',
              boxShadow: '0 0 12px rgba(108,76,255,0.6)',
            }}
          />

          {/* Nodes */}
          {NODES.map((node, i) => {
            const isLeft = i % 2 === 0;
            return (
              <motion.div
                key={i}
                initial={{ opacity: 0, x: isLeft ? -60 : 60 }}
                animate={isInView ? { opacity: 1, x: 0 } : {}}
                transition={{ duration: 0.6, delay: 0.2 + i * 0.15 }}
                style={{
                  display: 'flex',
                  justifyContent: isLeft ? 'flex-end' : 'flex-start',
                  alignItems: 'center',
                  marginBottom: 36,
                  paddingLeft: isLeft ? 0 : '52%',
                  paddingRight: isLeft ? '52%' : 0,
                  position: 'relative',
                }}
              >
                {/* Card */}
                <div style={{
                  background: 'rgba(255,255,255,0.03)',
                  backdropFilter: 'blur(20px)',
                  border: `1px solid ${node.color}30`,
                  borderRadius: 18,
                  padding: '20px 24px',
                  maxWidth: 340,
                  position: 'relative',
                  overflow: 'hidden',
                  transition: 'all 0.3s ease',
                }}>
                  <div style={{ position: 'absolute', top: 0, left: 0, right: 0, height: 2, background: `linear-gradient(90deg, transparent, ${node.color}, transparent)` }} />

                  <div style={{ display: 'flex', alignItems: 'center', gap: 10, marginBottom: 8 }}>
                    <span style={{ fontSize: 22 }}>{node.icon}</span>
                    <span style={{ fontSize: 11, color: node.color, letterSpacing: '0.15em', textTransform: 'uppercase', fontWeight: 600 }}>{node.month}</span>
                  </div>
                  <div style={{ fontSize: 15, fontWeight: 600, color: '#EAF4FF', marginBottom: 6 }}>{node.title}</div>
                  <div style={{ fontSize: 13, color: 'rgba(234,244,255,0.55)', lineHeight: 1.6 }}>{node.desc}</div>
                </div>

                {/* Center dot */}
                <div style={{
                  position: 'absolute',
                  left: '50%',
                  transform: 'translateX(-50%)',
                  width: 20,
                  height: 20,
                  borderRadius: '50%',
                  background: node.color,
                  boxShadow: `0 0 15px ${node.color}, 0 0 30px ${node.color}60`,
                  border: '3px solid #0C0F1E',
                  zIndex: 1,
                }} />
              </motion.div>
            );
          })}
        </div>
      </div>
    </div>
  );
}
