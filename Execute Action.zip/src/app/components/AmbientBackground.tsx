export function AmbientBackground() {
  return (
    <div
      style={{
        position: 'fixed',
        inset: 0,
        zIndex: 0,
        overflow: 'hidden',
        pointerEvents: 'none',
      }}
    >
      <style>{`
        @keyframes orb1 {
          0%   { transform: translate(0%, 0%) scale(1);    filter: hue-rotate(0deg); }
          25%  { transform: translate(8%, -12%) scale(1.15); filter: hue-rotate(40deg); }
          50%  { transform: translate(16%, 4%) scale(0.9);  filter: hue-rotate(80deg); }
          75%  { transform: translate(-6%, 14%) scale(1.2); filter: hue-rotate(30deg); }
          100% { transform: translate(0%, 0%) scale(1);    filter: hue-rotate(0deg); }
        }
        @keyframes orb2 {
          0%   { transform: translate(0%, 0%) scale(1);   }
          33%  { transform: translate(-14%, 10%) scale(1.25); }
          66%  { transform: translate(10%, -8%) scale(0.85); }
          100% { transform: translate(0%, 0%) scale(1);   }
        }
        @keyframes orb3 {
          0%   { transform: translate(0%,0%) scale(1); filter: hue-rotate(0deg); }
          50%  { transform: translate(-10%, -18%) scale(1.3); filter: hue-rotate(120deg); }
          100% { transform: translate(0%,0%) scale(1); filter: hue-rotate(0deg); }
        }
        @keyframes orb4 {
          0%   { transform: translate(0%,0%) scale(1.1); }
          40%  { transform: translate(12%, 8%) scale(0.85); }
          80%  { transform: translate(-8%, -12%) scale(1.3); }
          100% { transform: translate(0%,0%) scale(1.1); }
        }
        @keyframes orb5 {
          0%   { transform: translate(0%,0%) scale(1); filter: hue-rotate(0deg); }
          30%  { transform: translate(18%, -8%) scale(1.4); filter: hue-rotate(60deg); }
          60%  { transform: translate(-12%, 16%) scale(0.8); filter: hue-rotate(100deg); }
          100% { transform: translate(0%,0%) scale(1); filter: hue-rotate(0deg); }
        }

        @keyframes aurora1 {
          0%   { transform: translateX(-20%) skewX(-4deg) scaleY(1); opacity: 0.18; }
          50%  { transform: translateX(20%) skewX(4deg) scaleY(1.6); opacity: 0.32; }
          100% { transform: translateX(-20%) skewX(-4deg) scaleY(1); opacity: 0.18; }
        }
        @keyframes aurora2 {
          0%   { transform: translateX(15%) skewX(3deg) scaleY(1.2); opacity: 0.12; }
          50%  { transform: translateX(-18%) skewX(-5deg) scaleY(0.8); opacity: 0.25; }
          100% { transform: translateX(15%) skewX(3deg) scaleY(1.2); opacity: 0.12; }
        }
        @keyframes aurora3 {
          0%   { transform: translateX(0%) scaleY(1); opacity: 0.08; }
          33%  { transform: translateX(-12%) scaleY(2); opacity: 0.2; }
          66%  { transform: translateX(14%) scaleY(0.7); opacity: 0.15; }
          100% { transform: translateX(0%) scaleY(1); opacity: 0.08; }
        }

        @keyframes gridPulse {
          0%, 100% { opacity: 0.03; }
          50%  { opacity: 0.07; }
        }
        @keyframes scanH {
          0%   { top: -2px; opacity: 0; }
          5%   { opacity: 0.35; }
          95%  { opacity: 0.35; }
          100% { top: 100vh; opacity: 0; }
        }
        @keyframes scanH2 {
          0%   { top: -2px; opacity: 0; }
          5%   { opacity: 0.18; }
          95%  { opacity: 0.18; }
          100% { top: 100vh; opacity: 0; }
        }
        @keyframes vignetteBreath {
          0%, 100% { opacity: 0.55; }
          50%       { opacity: 0.72; }
        }
        @keyframes bgGradientShift {
          0%   { background-position: 0% 0%; }
          50%  { background-position: 100% 100%; }
          100% { background-position: 0% 0%; }
        }
        @keyframes crtFlicker {
          0%, 94%, 96%, 98%, 100% { opacity: 1; }
          95%, 97%, 99%           { opacity: 0.97; }
        }
        @keyframes cosmicRing1 {
          0%   { transform: translate(-50%,-50%) rotate(0deg) scale(1);   opacity: 0.06; }
          50%  { transform: translate(-50%,-50%) rotate(180deg) scale(1.08); opacity: 0.12; }
          100% { transform: translate(-50%,-50%) rotate(360deg) scale(1);  opacity: 0.06; }
        }
        @keyframes cosmicRing2 {
          0%   { transform: translate(-50%,-50%) rotate(0deg) scale(1);   opacity: 0.04; }
          50%  { transform: translate(-50%,-50%) rotate(-180deg) scale(1.12); opacity: 0.09; }
          100% { transform: translate(-50%,-50%) rotate(-360deg) scale(1); opacity: 0.04; }
        }
        @keyframes floatSlow {
          0%, 100% { transform: translateY(0px); }
          50%       { transform: translateY(-22px); }
        }
        @keyframes stardust {
          0%   { background-position: 0 0; }
          100% { background-position: 400px 400px; }
        }
      `}</style>

      {/* ─── Deep base gradient (animated) ─── */}
      <div
        style={{
          position: 'absolute',
          inset: 0,
          background:
            'radial-gradient(ellipse at 20% 30%, #0d0a2e 0%, #0C0F1E 50%, #06080f 100%)',
          backgroundSize: '300% 300%',
          animation: 'bgGradientShift 20s ease infinite',
        }}
      />

      {/* ─── Stardust texture overlay ─── */}
      <div
        style={{
          position: 'absolute',
          inset: 0,
          backgroundImage:
            'radial-gradient(circle, rgba(255,255,255,0.55) 1px, transparent 1px)',
          backgroundSize: '180px 180px',
          opacity: 0.035,
          animation: 'stardust 80s linear infinite',
        }}
      />

      {/* ─── Giant nebula orb 1 (violet, top-left) ─── */}
      <div
        style={{
          position: 'absolute',
          top: '-10%',
          left: '-8%',
          width: '65vw',
          height: '65vw',
          borderRadius: '50%',
          background:
            'radial-gradient(ellipse at 40% 40%, rgba(108,76,255,0.22) 0%, rgba(108,76,255,0.06) 45%, transparent 72%)',
          filter: 'blur(60px)',
          animation: 'orb1 18s ease-in-out infinite',
        }}
      />

      {/* ─── Giant nebula orb 2 (cyan, bottom-right) ─── */}
      <div
        style={{
          position: 'absolute',
          bottom: '-15%',
          right: '-10%',
          width: '60vw',
          height: '60vw',
          borderRadius: '50%',
          background:
            'radial-gradient(ellipse at 60% 60%, rgba(0,247,255,0.16) 0%, rgba(0,247,255,0.04) 50%, transparent 75%)',
          filter: 'blur(70px)',
          animation: 'orb2 22s ease-in-out infinite 3s',
        }}
      />

      {/* ─── Giant nebula orb 3 (pink, center-right) ─── */}
      <div
        style={{
          position: 'absolute',
          top: '30%',
          right: '-5%',
          width: '45vw',
          height: '45vw',
          borderRadius: '50%',
          background:
            'radial-gradient(ellipse, rgba(255,47,146,0.14) 0%, rgba(255,47,146,0.04) 55%, transparent 75%)',
          filter: 'blur(55px)',
          animation: 'orb3 26s ease-in-out infinite 7s',
        }}
      />

      {/* ─── Orb 4 (deep violet accent, bottom-left) ─── */}
      <div
        style={{
          position: 'absolute',
          bottom: '5%',
          left: '10%',
          width: '40vw',
          height: '40vw',
          borderRadius: '50%',
          background:
            'radial-gradient(ellipse, rgba(90,40,200,0.18) 0%, transparent 70%)',
          filter: 'blur(50px)',
          animation: 'orb4 20s ease-in-out infinite 4s',
        }}
      />

      {/* ─── Orb 5 (teal small, center-top) ─── */}
      <div
        style={{
          position: 'absolute',
          top: '-5%',
          left: '55%',
          width: '30vw',
          height: '30vw',
          borderRadius: '50%',
          background:
            'radial-gradient(ellipse, rgba(0,200,255,0.12) 0%, transparent 70%)',
          filter: 'blur(40px)',
          animation: 'orb5 15s ease-in-out infinite 1s',
        }}
      />

      {/* ─── Aurora ribbon 1 (bottom) ─── */}
      <div
        style={{
          position: 'absolute',
          bottom: '12%',
          left: 0,
          right: 0,
          height: '18vh',
          background:
            'linear-gradient(180deg, transparent 0%, rgba(108,76,255,0.08) 40%, rgba(0,247,255,0.12) 70%, rgba(108,76,255,0.06) 100%)',
          filter: 'blur(18px)',
          transformOrigin: 'bottom center',
          animation: 'aurora1 9s ease-in-out infinite',
        }}
      />

      {/* ─── Aurora ribbon 2 (top) ─── */}
      <div
        style={{
          position: 'absolute',
          top: '8%',
          left: 0,
          right: 0,
          height: '14vh',
          background:
            'linear-gradient(0deg, transparent 0%, rgba(255,47,146,0.07) 40%, rgba(108,76,255,0.1) 70%, rgba(0,247,255,0.06) 100%)',
          filter: 'blur(14px)',
          transformOrigin: 'top center',
          animation: 'aurora2 12s ease-in-out infinite 4s',
        }}
      />

      {/* ─── Aurora ribbon 3 (mid diagonal) ─── */}
      <div
        style={{
          position: 'absolute',
          top: '45%',
          left: '-10%',
          width: '120%',
          height: '8vh',
          background:
            'linear-gradient(90deg, transparent, rgba(0,247,255,0.05), rgba(108,76,255,0.08), rgba(255,47,146,0.05), transparent)',
          filter: 'blur(20px)',
          transformOrigin: 'center',
          animation: 'aurora3 16s ease-in-out infinite 2s',
        }}
      />

      {/* ─── Perspective grid ─── */}
      <div
        style={{
          position: 'absolute',
          inset: 0,
          backgroundImage:
            'linear-gradient(rgba(108,76,255,1) 1px, transparent 1px), linear-gradient(90deg, rgba(108,76,255,1) 1px, transparent 1px)',
          backgroundSize: '60px 60px',
          opacity: 0,
          animation: 'gridPulse 6s ease-in-out infinite',
        }}
      />

      {/* ─── Cosmic rotating rings ─── */}
      <div
        style={{
          position: 'absolute',
          top: '50%',
          left: '50%',
          width: '120vw',
          height: '120vw',
          border: '1px solid rgba(108,76,255,0.07)',
          borderRadius: '50%',
          animation: 'cosmicRing1 60s linear infinite',
        }}
      />
      <div
        style={{
          position: 'absolute',
          top: '50%',
          left: '50%',
          width: '90vw',
          height: '90vw',
          border: '1px solid rgba(0,247,255,0.05)',
          borderRadius: '50%',
          animation: 'cosmicRing2 40s linear infinite 5s',
        }}
      />
      <div
        style={{
          position: 'absolute',
          top: '50%',
          left: '50%',
          width: '70vw',
          height: '70vw',
          border: '1px solid rgba(255,47,146,0.04)',
          borderRadius: '50%',
          animation: 'cosmicRing1 80s linear infinite 10s',
        }}
      />

      {/* ─── Moving scan lines ─── */}
      <div
        style={{
          position: 'absolute',
          left: 0,
          right: 0,
          height: 2,
          background:
            'linear-gradient(90deg, transparent 0%, rgba(108,76,255,0.5) 20%, rgba(0,247,255,0.8) 50%, rgba(255,47,146,0.5) 80%, transparent 100%)',
          boxShadow: '0 0 12px rgba(108,76,255,0.4)',
          animation: 'scanH 8s linear infinite',
        }}
      />
      <div
        style={{
          position: 'absolute',
          left: 0,
          right: 0,
          height: 1,
          background:
            'linear-gradient(90deg, transparent 0%, rgba(0,247,255,0.4) 40%, rgba(108,76,255,0.5) 60%, transparent 100%)',
          animation: 'scanH2 13s linear infinite 4s',
        }}
      />

      {/* ─── Scanline CRT texture ─── */}
      <div
        style={{
          position: 'absolute',
          inset: 0,
          backgroundImage:
            'repeating-linear-gradient(0deg, transparent, transparent 2px, rgba(0,0,0,0.04) 2px, rgba(0,0,0,0.04) 4px)',
          pointerEvents: 'none',
          animation: 'crtFlicker 4s steps(1) infinite',
        }}
      />

      {/* ─── Radial vignette (breathing) ─── */}
      <div
        style={{
          position: 'absolute',
          inset: 0,
          background:
            'radial-gradient(ellipse at 50% 50%, transparent 35%, rgba(0,0,0,0.45) 70%, rgba(0,0,0,0.8) 100%)',
          animation: 'vignetteBreath 5s ease-in-out infinite',
        }}
      />

      {/* ─── Floating micro nebulae ─── */}
      {[
        { top: '22%', left: '8%', w: 200, color: 'rgba(108,76,255,0.18)', delay: '0s', dur: '11s' },
        { top: '65%', left: '78%', w: 160, color: 'rgba(0,247,255,0.14)', delay: '3s', dur: '14s' },
        { top: '45%', left: '40%', w: 140, color: 'rgba(255,47,146,0.1)', delay: '6s', dur: '18s' },
        { top: '80%', left: '20%', w: 180, color: 'rgba(0,180,255,0.12)', delay: '2s', dur: '13s' },
        { top: '12%', left: '65%', w: 120, color: 'rgba(200,100,255,0.15)', delay: '8s', dur: '10s' },
      ].map((n, i) => (
        <div
          key={i}
          style={{
            position: 'absolute',
            top: n.top,
            left: n.left,
            width: n.w,
            height: n.w,
            borderRadius: '50%',
            background: `radial-gradient(circle, ${n.color} 0%, transparent 70%)`,
            filter: 'blur(24px)',
            animation: `floatSlow ${n.dur} ease-in-out infinite ${n.delay}`,
          }}
        />
      ))}
    </div>
  );
}
