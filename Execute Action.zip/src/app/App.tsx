import { useRef, useState, useEffect, useCallback } from 'react';
import { AnimatePresence, motion } from 'motion/react';
import { ParticleCanvas } from './components/ParticleCanvas';
import { CursorGlow } from './components/CursorGlow';
import { NavDots } from './components/NavDots';
import { SlideTransitionOverlay } from './components/SlideTransitionOverlay';
import { AmbientBackground } from './components/AmbientBackground';
import { SpaceBackground } from './components/SpaceBackground';
import { Section01Hero } from './components/sections/Section01Hero';
import { Section02LatarBelakang } from './components/sections/Section02LatarBelakang';
import { Section03ProductReveal } from './components/sections/Section03ProductReveal';
import { Section04ValuePower } from './components/sections/Section04ValuePower';
import { Section05Financial } from './components/sections/Section05Financial';
import { Section06Strategy4P } from './components/sections/Section06Strategy4P';
import { Section07MarketAnalysis } from './components/sections/Section07MarketAnalysis';
import { Section08Roadmap } from './components/sections/Section08Roadmap';
import { Section09Competitive } from './components/sections/Section09Competitive';
import { Section10Vision } from './components/sections/Section10Vision';
import { Section11Impact } from './components/sections/Section11Impact';
import { Section12VideoReview } from './components/sections/Section12VideoReview';
import { Section12Closing } from './components/sections/Section12Closing';

const SECTION_NAMES = [
  'Hero Awakening',
  'Latar Belakang',
  'Product Reveal',
  'Value Power',
  'Analisis Keuangan',
  'Strategi 4P',
  'Analisis Pasar',
  'Rencana Pengembangan',
  'Keunggulan Kompetitif',
  'Visi & Misi',
  'Impact',
  'Video Review',
  'Closing',
];

const GlobalStyles = () => (
  <style>{`
    *, *::before, *::after { box-sizing: border-box; margin: 0; padding: 0; }

    html, body, #root {
      height: 100%;
      width: 100%;
      overflow: hidden;
      background: #0C0F1E;
      cursor: none;
    }

    ::-webkit-scrollbar { width: 3px; }
    ::-webkit-scrollbar-track { background: #0C0F1E; }
    ::-webkit-scrollbar-thumb { background: rgba(108,76,255,0.5); border-radius: 2px; }

    @keyframes float {
      0%, 100% { transform: translateY(0px); }
      50% { transform: translateY(-8px); }
    }
    @keyframes heroPulse {
      0%, 100% { opacity: 0.6; }
      50% { opacity: 1; }
    }
    @keyframes sweepText {
      0% { background-position: -200% center; }
      100% { background-position: 200% center; }
    }
    @keyframes btnPulse {
      0%, 100% { box-shadow: 0 0 30px rgba(108,76,255,0.4), 0 0 60px rgba(108,76,255,0.15), inset 0 0 20px rgba(108,76,255,0.1); }
      50% { box-shadow: 0 0 50px rgba(108,76,255,0.7), 0 0 80px rgba(108,76,255,0.3), inset 0 0 30px rgba(108,76,255,0.15); }
    }
    @keyframes scrollPulse {
      0%, 100% { opacity: 0.4; transform: scaleY(1); }
      50% { opacity: 0.8; transform: scaleY(1.2); }
    }
    @keyframes expandRing {
      0% { transform: scale(0.9); opacity: 0.7; }
      100% { transform: scale(1.5); opacity: 0; }
    }
    @keyframes shockwaveRing {
      0% { transform: translate(-50%,-50%) scale(0.8); opacity: 0.8; }
      100% { transform: translate(-50%,-50%) scale(1.6); opacity: 0; }
    }
    @keyframes shimmerBar {
      0% { background-position: -200% 0; }
      100% { background-position: 200% 0; }
    }
    @keyframes neonBorderCycle {
      0% { filter: hue-rotate(0deg); }
      100% { filter: hue-rotate(360deg); }
    }
    @keyframes ripple {
      0% { transform: scale(0); opacity: 0.6; }
      100% { transform: scale(4); opacity: 0; }
    }
    @keyframes hudPulse {
      0%, 100% { opacity: 0.7; }
      50% { opacity: 1; }
    }
    @keyframes progressGlow {
      0%, 100% { box-shadow: 0 0 6px rgba(108,76,255,0.6); }
      50% { box-shadow: 0 0 18px rgba(0,247,255,1), 0 0 36px rgba(108,76,255,0.6); }
    }
    @keyframes edgeGlowLeft {
      0%, 100% { opacity: 0.2; height: 30%; top: 35%; }
      50%       { opacity: 0.6; height: 50%; top: 25%; }
    }
    @keyframes edgeGlowRight {
      0%, 100% { opacity: 0.15; height: 25%; top: 38%; }
      50%       { opacity: 0.5; height: 45%; top: 28%; }
    }
    @keyframes topBarPulse {
      0%, 100% { opacity: 0.4; }
      50%       { opacity: 0.9; }
    }

    button { font-family: inherit; }
  `}</style>
);

/* ── Slide variants ─────────────────────────────────────────── */
const slideVariants = {
  enter: (dir: number) => ({
    y: dir > 0 ? '100%' : '-100%',
    opacity: 0,
    scale: 0.9,
    filter: 'blur(22px) brightness(0.4)',
  }),
  visible: {
    y: '0%',
    opacity: 1,
    scale: 1,
    filter: 'blur(0px) brightness(1)',
  },
  exit: (dir: number) => ({
    y: dir > 0 ? '-18%' : '18%',
    opacity: 0,
    scale: 1.1,
    filter: 'blur(16px) brightness(2)',
  }),
};

const slideTransition = {
  y: { type: 'spring' as const, stiffness: 280, damping: 28 },
  opacity: { duration: 0.38, ease: 'easeInOut' as const },
  scale: { duration: 0.55, ease: [0.25, 0.46, 0.45, 0.94] as const },
  filter: { duration: 0.45, ease: 'easeInOut' as const },
};

/* ── Keyboard hint ──────────────────────────────────────────── */
function KeyboardHint() {
  const [visible, setVisible] = useState(true);
  useEffect(() => {
    const t = setTimeout(() => setVisible(false), 6000);
    return () => clearTimeout(t);
  }, []);
  return (
    <AnimatePresence>
      {visible && (
        <motion.div
          initial={{ opacity: 0, y: 6 }}
          animate={{ opacity: 1, y: 0 }}
          exit={{ opacity: 0, y: 6 }}
          transition={{ duration: 0.5, delay: 2.5 }}
          style={{
            position: 'fixed',
            bottom: 18,
            right: 58,
            zIndex: 200,
            display: 'flex',
            alignItems: 'center',
            gap: 8,
            fontFamily: "'Space Grotesk', sans-serif",
            fontSize: 11,
            color: 'rgba(234,244,255,0.3)',
            letterSpacing: '0.08em',
          }}
        >
          <kbd style={{
            padding: '2px 7px',
            border: '1px solid rgba(108,76,255,0.3)',
            borderRadius: 5,
            fontFamily: 'inherit',
            fontSize: 10,
            color: 'rgba(234,244,255,0.4)',
            background: 'rgba(108,76,255,0.08)',
          }}>↑↓</kbd>
          <span>or scroll to navigate</span>
        </motion.div>
      )}
    </AnimatePresence>
  );
}

/* ── Main App ───────────────────────────────────────────────── */
export default function App() {
  const [activeSection, setActiveSection] = useState(0);
  const [direction, setDirection] = useState(1);
  const [transitionCount, setTransitionCount] = useState(0);
  const lastNavTime = useRef<number>(Date.now() - 1200);
  const touchStartY = useRef(0);

  const navigateTo = useCallback(
    (index: number) => {
      const now = Date.now();
      if (now - lastNavTime.current < 780) return;
      if (index < 0 || index > 12) return;
      if (index === activeSection) return;

      lastNavTime.current = now;
      setDirection(index > activeSection ? 1 : -1);
      setActiveSection(index);
      setTransitionCount((c) => c + 1);
      window.dispatchEvent(new Event('slideBurst'));
    },
    [activeSection],
  );

  /* Keyboard */
  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      if (['ArrowDown', 'ArrowRight', ' ', 'PageDown'].includes(e.key)) {
        e.preventDefault();
        navigateTo(activeSection + 1);
      } else if (['ArrowUp', 'ArrowLeft', 'PageUp'].includes(e.key)) {
        e.preventDefault();
        navigateTo(activeSection - 1);
      }
    };
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  }, [navigateTo, activeSection]);

  /* Wheel */
  useEffect(() => {
    const onWheel = (e: WheelEvent) => {
      e.preventDefault();
      if (e.deltaY > 20) navigateTo(activeSection + 1);
      else if (e.deltaY < -20) navigateTo(activeSection - 1);
    };
    window.addEventListener('wheel', onWheel, { passive: false });
    return () => window.removeEventListener('wheel', onWheel);
  }, [navigateTo, activeSection]);

  /* Touch */
  useEffect(() => {
    const onTouchStart = (e: TouchEvent) => { touchStartY.current = e.touches[0].clientY; };
    const onTouchEnd = (e: TouchEvent) => {
      const delta = touchStartY.current - e.changedTouches[0].clientY;
      if (Math.abs(delta) > 60) {
        if (delta > 0) navigateTo(activeSection + 1);
        else navigateTo(activeSection - 1);
      }
    };
    window.addEventListener('touchstart', onTouchStart);
    window.addEventListener('touchend', onTouchEnd);
    return () => {
      window.removeEventListener('touchstart', onTouchStart);
      window.removeEventListener('touchend', onTouchEnd);
    };
  }, [navigateTo, activeSection]);

  const sections = [
    <Section01Hero key={0} onStart={() => navigateTo(1)} />,
    <Section02LatarBelakang key={1} />,
    <Section03ProductReveal key={2} />,
    <Section04ValuePower key={3} />,
    <Section05Financial key={4} />,
    <Section06Strategy4P key={5} />,
    <Section07MarketAnalysis key={6} />,
    <Section08Roadmap key={7} />,
    <Section09Competitive key={8} />,
    <Section10Vision key={9} />,
    <Section11Impact key={10} />,
    <Section12VideoReview key={11} />,
    <Section12Closing key={12} />,
  ];

  const progress = (activeSection + 1) / 13;

  return (
    <>
      <GlobalStyles />

      {/* ── Layer 0: Ambient CSS background ── */}
      <AmbientBackground />

      {/* ── Layer 0.5: Space Background with stars and objects ── */}
      <SpaceBackground />

      {/* ── Layer 1: Canvas particles ── */}
      <ParticleCanvas />

      {/* ── Layer 2: Cursor ── */}
      <CursorGlow />

      {/* ── Edge neon glows (left & right borders) ── */}
      <div style={{
        position: 'fixed', left: 0, top: '35%', width: 3, height: '30%',
        background: 'linear-gradient(to bottom, transparent, #6C4CFF, #00F7FF, transparent)',
        boxShadow: '0 0 20px rgba(108,76,255,0.8), 0 0 40px rgba(108,76,255,0.4)',
        borderRadius: '0 2px 2px 0',
        zIndex: 50, pointerEvents: 'none',
        animation: 'edgeGlowLeft 4s ease-in-out infinite',
      }} />
      <div style={{
        position: 'fixed', right: 0, top: '38%', width: 3, height: '25%',
        background: 'linear-gradient(to bottom, transparent, #FF2F92, #6C4CFF, transparent)',
        boxShadow: '0 0 20px rgba(255,47,146,0.7), 0 0 40px rgba(255,47,146,0.3)',
        borderRadius: '2px 0 0 2px',
        zIndex: 50, pointerEvents: 'none',
        animation: 'edgeGlowRight 5.5s ease-in-out infinite 1.5s',
      }} />

      {/* ── Top HUD bar ── */}
      <div style={{
        position: 'fixed', top: 0, left: 0, right: 0, height: 1,
        background: 'linear-gradient(90deg, transparent 0%, rgba(108,76,255,0.6) 20%, rgba(0,247,255,0.9) 50%, rgba(255,47,146,0.6) 80%, transparent 100%)',
        zIndex: 200, pointerEvents: 'none',
        animation: 'topBarPulse 3s ease-in-out infinite',
        boxShadow: '0 0 12px rgba(108,76,255,0.5)',
      }} />

      {/* ── Cinematic transition overlay ── */}
      <SlideTransitionOverlay trigger={transitionCount} direction={direction} />

      {/* ── Slide container ── */}
      <div style={{ position: 'fixed', inset: 0, zIndex: 10, overflow: 'hidden' }}>
        <AnimatePresence custom={direction} mode="wait">
          <motion.div
            key={activeSection}
            custom={direction}
            variants={slideVariants}
            initial="enter"
            animate="visible"
            exit="exit"
            transition={slideTransition}
            style={{ position: 'absolute', inset: 0, overflowY: 'auto' }}
          >
            {sections[activeSection]}
          </motion.div>
        </AnimatePresence>
      </div>

      {/* ── Navigation dots ── */}
      <NavDots activeSection={activeSection} onDotClick={navigateTo} />

      {/* ── Progress bar ── */}
      <div style={{
        position: 'fixed', bottom: 0, left: 0, right: 0, height: 2,
        background: 'rgba(108,76,255,0.08)', zIndex: 200,
      }}>
        <motion.div
          style={{
            height: '100%',
            background: 'linear-gradient(90deg, #6C4CFF 0%, #00F7FF 50%, #FF2F92 100%)',
            originX: 0,
            animation: 'progressGlow 2.5s ease-in-out infinite',
          }}
          animate={{ scaleX: progress }}
          transition={{ duration: 0.65, ease: [0.25, 0.46, 0.45, 0.94] }}
        />
      </div>

      {/* ── Bottom HUD ── */}
      <div style={{
        position: 'fixed', bottom: 16, left: 32, zIndex: 200,
        display: 'flex', alignItems: 'center', gap: 12,
        fontFamily: "'Space Grotesk', sans-serif",
      }}>
        <AnimatePresence mode="wait">
          <motion.span
            key={`num-${activeSection}`}
            initial={{ opacity: 0, y: 8 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -8 }}
            transition={{ duration: 0.22 }}
            style={{
              fontFamily: "'Orbitron', monospace", fontSize: 13, color: '#6C4CFF',
              letterSpacing: '0.25em', textShadow: '0 0 12px rgba(108,76,255,0.8)',
              animation: 'hudPulse 3s ease-in-out infinite',
            }}
          >
            {String(activeSection + 1).padStart(2, '0')}
          </motion.span>
        </AnimatePresence>

        <div style={{ width: 28, height: 1, background: 'linear-gradient(90deg, rgba(108,76,255,0.6), rgba(0,247,255,0.3))' }} />

        <AnimatePresence mode="wait">
          <motion.span
            key={`name-${activeSection}`}
            initial={{ opacity: 0, x: -8 }}
            animate={{ opacity: 1, x: 0 }}
            exit={{ opacity: 0, x: 8 }}
            transition={{ duration: 0.25 }}
            style={{ fontSize: 11, color: 'rgba(234,244,255,0.45)', letterSpacing: '0.12em', textTransform: 'uppercase' }}
          >
            {SECTION_NAMES[activeSection]}
          </motion.span>
        </AnimatePresence>

        <div style={{ width: 28, height: 1, background: 'linear-gradient(90deg, rgba(0,247,255,0.3), rgba(108,76,255,0.1))' }} />

        <span style={{ fontFamily: "'Orbitron', monospace", fontSize: 11, color: 'rgba(234,244,255,0.15)', letterSpacing: '0.2em' }}>13</span>

        <div style={{ display: 'flex', gap: 4, marginLeft: 8 }}>
          {Array.from({ length: 13 }, (_, i) => (
            <motion.div
              key={i}
              onClick={() => navigateTo(i)}
              animate={{
                width: i === activeSection ? 16 : 4,
                background: i === activeSection ? '#6C4CFF' : i < activeSection ? 'rgba(108,76,255,0.4)' : 'rgba(234,244,255,0.12)',
                boxShadow: i === activeSection ? '0 0 8px rgba(108,76,255,0.8)' : 'none',
              }}
              transition={{ duration: 0.3 }}
              style={{ height: 4, borderRadius: 2, cursor: 'pointer' }}
            />
          ))}
        </div>
      </div>

      {/* ── Keyboard hint ── */}
      <KeyboardHint />
    </>
  );
}