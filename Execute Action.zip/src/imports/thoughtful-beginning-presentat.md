Siap.
Ini **MASTER PROMPT ULTRA RARE – SIAP COPY PASTE KE FIGMA AI / MAKE**

Tanpa teks tambahan. Tinggal copas.

---

# 🎮 MASTER PROMPT – LIVING CINEMATIC PRESENTATION

**Project: Thoughtful Beginning**

Create a full interactive cinematic presentation website (not static slides) with mobile game energy UI style, ultra premium, futuristic, smooth animation ready.

Theme: Cosmic Neon Motivation
Tone: Youthful, inspiring, powerful, elegant
Target: School presentation but visually world-class

---

## 🎨 GLOBAL DESIGN SYSTEM

Use these colors consistently:

Base background: #0C0F1E (deep cosmic dark)
Primary glow: #6C4CFF (violet energy)
Secondary glow: #00F7FF (neon cyan)
Accent glow: #FF2F92 (electric magenta)
Text primary: #EAF4FF

Add soft outer glow 15–25% opacity.
Use layered lighting and radial glow effects.
Use glassmorphism cards (backdrop blur 20px).
Add subtle floating particle background.
Add animated gradient border on key components.

Style reference:
Mobile game hero intro + Apple keynote smoothness + futuristic UI system.

Each section must be full-screen (1440x1024 desktop frame).
Design ready for smooth scroll snap and animated transitions.

---

# ⚔️ SECTION 1 – HERO AWAKENING

Design a full-screen cinematic hero intro.

Background:
Dark cosmic gradient with radial violet glow center and subtle floating particles.

Center aligned:

Headline:
THOUGHTFUL BEGINNING

Subheadline:
Hampers Alat Tulis Estetik untuk Pelajar Modern

Supporting text:
Sebuah hadiah sederhana yang membawa semangat baru dalam setiap langkah pendidikan.

Button:
Mulai Presentasi

Effects:
Gradient headline (purple to cyan), soft glow, light sweep animation across text, floating button with subtle pulse glow.

---

# 📖 SECTION 2 – LATAR BELAKANG

Create split layout 60/40.

Left:
Narrative text in glass card container.

Text:
Di era modern, pelajar tidak hanya membutuhkan alat tulis.
Mereka membutuhkan motivasi.

Hadiah bukan sekadar barang.
Hadiah adalah simbol perhatian, doa, dan dukungan.

Thoughtful Beginning hadir sebagai hampers alat tulis estetik yang memberikan makna di setiap detailnya.

Right:
Glowing gift box illustration with neon aura and subtle floating motion.

Add smooth reveal animation placeholders.

---

# 💎 SECTION 3 – PRODUCT REVEAL

Full-screen cinematic reveal.

Center:
Floating 3D product box mockup with neon shockwave ring effect.

Below:
4 glass cards horizontally:

Notebook Premium Minimalis
Pulpen Estetik
Sticky Notes Pastel
Kartu Motivasi Personal

Add hover glow interaction and subtle tilt effect.

---

# ⚡ SECTION 4 – VALUE POWER SYSTEM

Create 4 glowing power cards grid.

Titles:

Fungsional
Estetik
Emosional
Terjangkau

Add neon animated border effect and hover glow pulse.

Under grid add text:

Bukan hanya produk. Ini adalah pengalaman.

---

# 📊 SECTION 5 – ANALISIS KEUANGAN

Split layout.

Left:
Neon progress bars labeled:

Modal Produksi – Rp 90.000
Harga Jual – Rp 120.000
Keuntungan – Rp 30.000

Right:
Large glowing counter numbers.

Add animated fill placeholders and glow flash effect when completed.

---

# 🗺 SECTION 6 – STRATEGI 4P

Interactive tab layout:

Tabs:
Product
Price
Place
Promotion

Content:

Product: Hampers estetik berkualitas.
Price: Terjangkau untuk pelajar.
Place: Online & pemesanan langsung.
Promotion: Media sosial dan rekomendasi teman.

Active tab underline neon animation.

---

# 📈 SECTION 7 – ANALISIS PASAR

Create animated neon bar chart visualization.

Text:

Target: Pelajar SMP & SMA.
Segmentasi: Usia 13–18 tahun.
Potensi pasar luas dan terus bertumbuh.

Dark background with cyan glow data bars.

---

# 🚀 SECTION 8 – RENCANA PENGEMBANGAN

Vertical glowing roadmap timeline.

Nodes:

Bulan 1: Persiapan & Desain
Bulan 2: Produksi Awal
Bulan 3: Peluncuran
Bulan 4: Promosi Intensif
Bulan 5: Evaluasi
Bulan 6: Pengembangan Varian Baru

Animated glowing line progression.

---

# 🌟 SECTION 9 – KEUNGGULAN KOMPETITIF

Create glowing icon cards grid.

Content:

Desain unik
Harga ramah pelajar
Nilai emosional tinggi
Kemasan estetik

Hover effect: glow + scale 1.03.

---

# 🌌 SECTION 10 – VISI

Full-screen centered inspirational layout.

Text:

Menjadi hampers pilihan utama pelajar Indonesia
yang tidak hanya memberikan alat tulis,
tetapi juga semangat dan inspirasi.

Add cinematic light burst background and soft particle glow.

---

# 🏆 SECTION 11 – IMPACT

Large typography statement layout.

Text:

Meningkatkan motivasi belajar.
Memberikan makna dalam setiap hadiah.
Membangun usaha kreatif yang berkelanjutan.

Highlight key words with neon glow gradient.

---

# 🎉 SECTION 12 – CLOSING CINEMATIC

Dark cosmic background with subtle energy flare.

Center text:

THOUGHTFUL BEGINNING

Bukan Sekadar Hadiah.
Ini adalah Awal yang Penuh Makna.

Terima Kasih.

Add fade out ending animation placeholder.

---

# 🎬 MOTION & INTERACTION REQUIREMENTS

Add placeholders for:

Smooth scroll snap
Fade in stagger animation
Glow pulse loop
Light sweep animation
Hover tilt effect
Neon border animation
Particle background layer
Section blur transition

Design must feel like interactive gaming UI experience, not static slides.

---

END OF PROMPT.
