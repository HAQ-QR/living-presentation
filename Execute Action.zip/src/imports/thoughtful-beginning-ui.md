Tema: Thoughtful Beginning
Style: Cosmic Neon Experience UI

🎮 MASTER DESIGN SYSTEM
🎨 Color DNA (Final)

Base Void: #0C0F1E
Deep Violet: #6C4CFF
Neon Cyan: #00F7FF
Electric Magenta: #FF2F92
Soft Ice White: #EAF4FF

Glow rule:
Outer glow 15–25% opacity
Blur radius 20–40px

🧠 GLOBAL UI RULES

Full screen per section (1440x1024 desktop frame)

Layered background (gradient + particle + blur orb)

Glassmorphism cards (backdrop blur 20)

Soft floating animation (3–6px infinite ease-in-out)

Scroll snap

Micro interaction everywhere

⚔️ SCENE 1 — HERO AWAKENING
🎨 Layout Blueprint

Full screen center alignment.

Background:
Dark gradient radial purple center glow.

Foreground:
Main title center.
Subtitle below.
Start button below.

✍️ TEXT FINAL

THOUGHTFUL BEGINNING
Hampers Alat Tulis Estetik untuk Pelajar Modern

Sebuah hadiah sederhana yang membawa semangat baru dalam setiap langkah pendidikan.

Button:
Mulai Presentasi

🤖 PROMPT UNTUK FIGMA AI

“Create a full-screen cinematic hero section with dark cosmic background, radial violet glow center, floating light particles, glassmorphism start button, neon gradient headline (purple to cyan), subtle glow, modern gaming UI style, smooth layered lighting, high contrast, futuristic presentation layout.”

📖 SCENE 2 — LATAR BELAKANG
🎨 Layout

Split 60/40.

Left:
Text block vertical reveal.

Right:
Illustration gift box glowing aura.

✍️ TEXT FINAL

Di era modern, pelajar tidak hanya membutuhkan alat tulis.
Mereka membutuhkan motivasi.

Hadiah bukan sekadar barang.
Hadiah adalah simbol perhatian, doa, dan dukungan.

Thoughtful Beginning hadir sebagai hampers alat tulis estetik yang memberikan makna di setiap detailnya.

🤖 PROMPT

“Design split layout presentation section, left text narrative reveal, right glowing gift box illustration with soft neon aura, dark purple background, cinematic storytelling UI, smooth animation ready, glass card container.”

💎 SCENE 3 — PRODUCT REVEAL
🎨 Layout

Center floating box 3D mockup.

Under it:
3 glass cards horizontal.

✍️ TEXT FINAL

Isi Paket:

• Notebook Premium Minimalis
• Pulpen Estetik
• Sticky Notes Warna Pastel
• Kartu Motivasi Personal

Dikemas dalam box elegan dengan sentuhan modern.

🤖 PROMPT

“Create a futuristic product reveal scene, floating 3D box mockup center with neon glow ring shockwave, glassmorphism feature cards below, subtle purple and cyan lighting, high-end gaming UI aesthetic.”

⚡ SCENE 4 — VALUE POWER SYSTEM
🎨 Layout

4 power cards grid.

Each card glowing border.

✍️ TEXT FINAL

Fungsional
Estetik
Emosional
Terjangkau

Bukan hanya produk.
Ini adalah pengalaman.

🤖 PROMPT

“Design four glowing power cards in grid layout, neon animated borders, hover glow effect, cosmic dark background, high energy UI like mobile game skill system.”

📊 SCENE 5 — ANALISIS KEUANGAN
🎨 Layout

Left:
Animated power bars.

Right:
Big glowing numbers.

✍️ TEXT FINAL

Modal Produksi: Rp 90.000
Harga Jual: Rp 120.000
Keuntungan: Rp 30.000

Margin sehat dan berkelanjutan untuk pengembangan usaha.

🤖 PROMPT

“Create financial stats section with animated neon progress bars, glowing counter numbers, dark futuristic theme, cyan and magenta highlights, premium business presentation UI.”

🗺 SCENE 6 — STRATEGI 4P
✍️ TEXT FINAL

Product: Hampers estetik berkualitas.
Price: Terjangkau untuk pelajar.
Place: Online & pemesanan langsung.
Promotion: Media sosial dan rekomendasi teman.

🤖 PROMPT

“Interactive tab layout for marketing strategy (4P), neon underline animation, glass background panel, dark cosmic UI, modern presentation style.”

📈 SCENE 7 — ANALISIS PASAR
✍️ TEXT FINAL

Target: Pelajar SMP & SMA.
Segmentasi: Usia 13–18 tahun.
Potensi pasar luas dan terus bertumbuh.

🤖 PROMPT

“Create animated bar chart presentation with neon cyan glow bars, dark gradient background, subtle particle effect, modern data visualization UI.”

🚀 SCENE 8 — RENCANA PENGEMBANGAN
✍️ TEXT FINAL

Bulan 1: Persiapan & Desain
Bulan 2: Produksi Awal
Bulan 3: Peluncuran
Bulan 4: Promosi Intensif
Bulan 5: Evaluasi
Bulan 6: Pengembangan Varian Baru

🤖 PROMPT

“Design futuristic vertical roadmap timeline with glowing nodes, animated line progression, dark purple neon style, presentation mode UI.”

🧠 SCENE 9 — KEUNGGULAN KOMPETITIF
✍️ TEXT FINAL

Desain unik
Harga ramah pelajar
Nilai emosional tinggi
Kemasan estetik

🤖 PROMPT

“Create competitive advantage showcase with glowing icon cards, hover interaction, neon gradient highlights, minimal but powerful gaming UI design.”

🌟 SCENE 10 — VISI
✍️ TEXT FINAL

Menjadi hampers pilihan utama pelajar Indonesia
yang tidak hanya memberikan alat tulis,
tetapi juga semangat dan inspirasi.

🤖 PROMPT

“Full screen inspirational section with animated light burst background, centered glowing headline, soft cinematic motion, elegant futuristic theme.”

🏆 SCENE 11 — IMPACT
✍️ TEXT FINAL

Meningkatkan motivasi belajar.
Memberikan makna dalam setiap hadiah.
Membangun usaha kreatif yang berkelanjutan.

🤖 PROMPT

“Create impactful statement section with large typography, neon glow highlight keywords, floating ambient light particles, immersive presentation design.”

🎉 SCENE 12 — VICTORY SCREEN
✍️ TEXT FINAL

THOUGHTFUL BEGINNING

Bukan Sekadar Hadiah.
Ini adalah Awal yang Penuh Makna.

Terima Kasih.

🤖 PROMPT

“Cinematic closing screen with subtle energy explosion light, floating particles, glowing gradient typography, dark cosmic theme, smooth fade out presentation ending.”

🔥 ULTRA RARE UX ADDITIONS

Tambahkan di Figma:

Animated gradient borders

Cursor glow trail

Button ripple effect

Micro hover scale 1.03

Scroll snap

Light sweep on headings

Subtle ambient particle animation layer

🧠 FINAL RESULT

Kalau ini kamu eksekusi dengan animasi:

Presentasi kamu akan terasa seperti:

Event launching

Game UI experience

Bukan tugas sekolah biasa

Level jauh di atas rata-rata